<?php

// Prevent loading this file directly

defined( 'ABSPATH' ) || exit;



if ( ! class_exists( 'WB_Radio_Field' ) )

{

	class WB_Radio_Field extends WB_Field

	{

		/**

		 * Get field HTML

		 *

		 * @param mixed  $meta

		 * @param array  $field

		 *

		 * @return string

		 */

		static function html( $meta, $field )

		{

			$html = array();

			$tpl = '<label><input type="radio" class="wb-radio" name="%s" value="%s"%s> %s</label>';



			foreach ( $field['options'] as $value => $label )

			{

				$html[] = sprintf(

					$tpl,

					$field['field_name'],

					$value,

					checked( $value, $meta, false ),

					$label

				);

			}



			return implode( ' ', $html );

		}

	}

}

