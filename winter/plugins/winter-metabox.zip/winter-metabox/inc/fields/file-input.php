<?php
if ( !class_exists( 'WB_File_Input_Field' ) )
{
	class WB_File_Input_Field extends WB_Field
	{
		/**
		 * Enqueue scripts and styles
		 *
		 * @return void
		 */
		static function admin_enqueue_scripts()
		{
			// Make sure scripts for new media uploader in WordPress 3.5 is enqueued
			wp_enqueue_media();
			wp_enqueue_script( 'wb-file-input', WB_JS_URL . 'file-input.js', array( 'jquery' ), WB_VER, true );
			wp_localize_script( 'wb-file-input', 'wbFileInput', array(
				'frameTitle' => esc_html__( 'Select File', 'harvest' ),
			) );
		}

		/**
		 * Get field HTML
		 *
		 * @param mixed  $meta
		 * @param array  $field
		 *
		 * @return string
		 */
		static function html( $meta, $field )
		{
			return sprintf(
				'<input type="text" class="wb-file-input" name="%s" id="%s" value="%s" placeholder="%s" size="%s">
				<a href="#" class="wb-file-input-select button-primary">%s</a>
				<a href="#" class="wb-file-input-remove button %s">%s</a>',
				$field['field_name'],
				$field['id'],
				$meta,
				$field['placeholder'],
				$field['size'],
				esc_html__( 'Select', 'harvest' ),
				$meta ? '' : 'hidden',
				esc_html__( 'Remove', 'harvest' )
			);
		}

		/**
		 * Normalize parameters for field
		 *
		 * @param array $field
		 *
		 * @return array
		 */
		static function normalize_field( $field )
		{
			$field = wp_parse_args( $field, array(
				'size'        => 30,
				'placeholder' => '',
			) );
			return $field;
		}
	}
}