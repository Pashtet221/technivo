/**
 * Update color picker element
 * Used for static & dynamic added elements (when clone)
 */
jQuery( document ).ready( function( $ )
{	
	"use strict";
	$( ':input.wb-color' ).each( wb_update_color_picker );
	$( '.wb-input' ).on( 'clone', ':input.wb-color', wb_update_color_picker )
	.on( 'focus', '.wb-color', function()
	{
		$( this ).siblings( '.wb-color-picker' ).show();
		return false;
	} ).on( 'blur',  '.wb-color', function()
	{
		$( this ).siblings( '.wb-color-picker' ).hide();
		return false;
	} );
	
	function wb_update_color_picker()
	{
		var $this = $( this ),
			$clone_container = $this.closest('.wb-clone'),
			$color_picker = $this.siblings( '.wb-color-picker' );
		
		// Make sure the value is displayed
		if ( !$this.val() )
			$this.val( '#' );
			
		if( typeof jQuery.wp === 'object' && typeof jQuery.wp.wpColorPicker === 'function' ){
			if( $clone_container.length > 0 )
			{
				$this.appendTo( $clone_container ).siblings( 'div.wp-picker-container' ).remove();
			}
        	$this.wpColorPicker();
		}
		else {
			//We use farbtastic if the WordPress color picker widget doesn't exist
			$color_picker.farbtastic( $this );			
		}			
	}

} ); 