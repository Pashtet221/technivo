jQuery( function( $ )
{
	"use strict";
	$( ':input.wb-slider-value' ).each( wb_update_slider );
	$( '.wb-input' ).on( 'clone', ':input.wb-slider-value', wb_update_slider );

	function wb_update_slider()
	{
		var $input = $( this ),
			$slider = $input.siblings( '.wb-slider' ),
			$valueLabel = $slider.siblings( '.wb-slider-value-label' ).find( 'span' ),
			value = $input.val(),
			options = $slider.data( 'options' );

		$slider.html( '' );

		if ( !value )
		{
			value = 0;
			$input.val( 0 );
			$valueLabel.text( '0' );
		}
		else
		{
			$valueLabel.text( value );
		}

		// Assign field value and callback function when slide
		options.value = value;
		options.slide = function( event, ui )
		{
			$input.val( ui.value );
			$valueLabel.text( ui.value );
		};

		$slider.slider( options );
	}
} );
 