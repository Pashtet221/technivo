/**
 * Update datetime picker element
 * Used for static & dynamic added elements (when clone)
 */
jQuery( document ).ready( function( $ )
{
	"use strict";
	$( ':input.wb-datetime' ).each( wb_update_datetime_picker );
	$( '.wb-input' ).on( 'clone', ':input.wb-datetime', wb_update_datetime_picker );
	
	function wb_update_datetime_picker()
	{
		var $this = $( this ),
			options = $this.data( 'options' );
	
		$this.siblings( '.ui-datepicker-append' ).remove();         // Remove appended text
		$this.removeClass( 'hasDatepicker' ).attr( 'id', '' ).datetimepicker( options );
	
	}
} );
 