<?php

// Webibazaar Testimonials
if( ! function_exists( 'testimonial_theme_custom_posts' ) ) {
	
  function testimonial_theme_custom_posts(){
    //testimonial
    $labels = array(
      'name' => _x('Testimonials', 'Testimonial','technivo'),
      'singular_name' => _x('Testimonial', 'testimonial','technivo'),
      'add_new' => _x('Add New', 'Testimonial','technivo'),
      'add_new_item' => __('Add New Testimonial','technivo'),
      'edit_item' => __('Edit Testimonial','technivo'),
      'new_item' => __('New Testimonial','technivo'),
      'view_item' => __('View Testimonial','technivo'),
      'search_items' => __('Search Testimonial','technivo'),
      'not_found' =>  __('No Testimonial found','technivo'),
      'not_found_in_trash' => __('No Testimonial found in Trash','technivo'), 
      'parent_item_colon' => ''
    );
    $args = array(
      'labels' => $labels,
      'public' => true,
      'publicly_queryable' => true,
      'show_ui' => true, 
      'query_var' => true, 
      'capability_type' => 'post', 
      'menu_position' => null,
      'menu_icon' => 'dashicons-format-chat',  
      'rewrite' => array('slug'=>'testimonial','with_front'=>''),
      'supports' => array('title','editor','author','thumbnail','comments')
    ); 
    register_post_type('testimonial',$args);  
  }
  add_filter('init', 'testimonial_theme_custom_posts' );
  add_action( 'admin_init', 'remove_metabox_option' );
}

if( ! function_exists( 'remove_metabox_option' ) ) {
	
	function remove_metabox_option() {
		remove_meta_box( 'commentsdiv', 'testimonial', 'normal' );
		remove_meta_box( 'authordiv', 'testimonial', 'normal' );
		remove_meta_box( 'commentstatusdiv', 'testimonial', 'normal' );
	}
  add_action( 'add_meta_boxes', 'testimonial_add_custom_fields' );
  add_action( 'save_post', 'testimonial_save_custom_fields' );
  
}

if( ! function_exists( 'testimonial_add_custom_fields' ) ) {
  function testimonial_add_custom_fields() {
      add_meta_box( 
          'testimonial_options',
          'Testimonial Information',
          'testimonial_inner_custom_field',
          'testimonial' 
      );
  }
}

if( ! function_exists( 'testimonial_inner_custom_field' ) ) {
  function testimonial_inner_custom_field( $post ) {
    // Use nonce for verification
    wp_nonce_field( plugin_basename( __FILE__ ), '_Winter' ); 
    get_post_meta($post->ID, 'testimonial_position', TRUE) ? $testimonial_position = get_post_meta($post->ID, 'testimonial_position', TRUE) : $testimonial_position = '';
    get_post_meta($post->ID, 'testimonial_link', TRUE) ? $testimonial_link = get_post_meta($post->ID, 'testimonial_link', TRUE) : $testimonial_link = '';
  ?>
  <table class="form-table">
    <tbody>
      <tr valign="top">
        <th><label for="testimonial_position">
          <?php _e('Designation:', 'technivo'); ?>
          </label></th>
        <td><input type="text" id="testimonial_position" name="testimonial_position" value="<?php echo esc_attr($testimonial_position); ?>" class="regular-text"/></td>
      </tr>
      <tr valign="top">
        <th><label for="testimonial_link">
          <?php _e('Link:', 'technivo'); ?>
          </label></th>
        <td><input type="text" id="testimonial_link" name="testimonial_link" value="<?php echo esc_attr($testimonial_link); ?>" class="regular-text" /></td>
      </tr>
    </tbody>
  </table>
  <?php }
}

if( ! function_exists( 'testimonial_save_custom_fields' ) ) {
  function testimonial_save_custom_fields( $post_id ) {
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) 
        return;
    if ( !current_user_can( 'edit_post', $post_id ) )
          return;
    $mydata = array();
    foreach($_POST as $key => $data) {
      if($key == '_Winter')
        continue;
      
      if(preg_match('/^testimonial/i', $key)) {
        $mydata[$key] = $data;
      update_post_meta($post_id, $key, $data); 
      }
    }
  
    return $mydata;
    
  }
} 

// Webibazaar Staff
if( ! function_exists( 'staff_theme_custom_posts' ) ) {
  function staff_theme_custom_posts(){
    //staff
    $labels = array(
      'name' => _x('Staff', 'Staff','technivo'),
      'singular_name' => _x('Staff', 'staff','technivo'),
      'add_new' => _x('Add New', 'Staff','technivo'),
      'add_new_item' => __('Add New Staff','technivo'),
      'edit_item' => __('Edit Staff','technivo'),
      'new_item' => __('New Staff','technivo'),
      'view_item' => __('View Staff','technivo'),
      'search_items' => __('Search Staff','technivo'),
      'not_found' =>  __('No Staff found','technivo'),
      'not_found_in_trash' => __('No Staff found in Trash','technivo'), 
      'parent_item_colon' => ''
    );
    $args = array(
      'labels' => $labels,
      'public' => true,
      'publicly_queryable' => true,
      'show_ui' => true, 
      'query_var' => true, 
      'capability_type' => 'post', 
      'menu_position' => null,
      'menu_icon' => 'dashicons-businessperson',  
      'rewrite' => array('slug'=>'staff','with_front'=>''),
      'supports' => array('title','editor','author','thumbnail','comments')
    ); 
    register_post_type('staff',$args);  
  }
 
  add_filter('init', 'staff_theme_custom_posts' );
  
  add_action( 'admin_init', 'staff_remove_metabox_option' );
  
  
  if( ! function_exists( 'staff_remove_metabox_option' ) ) {
   
  }
  function staff_remove_metabox_option() {
    remove_meta_box( 'commentsdiv', 'staff', 'normal' );
    remove_meta_box( 'authordiv', 'staff', 'normal' );
    remove_meta_box( 'commentstatusdiv', 'staff', 'normal' );

  }
  
  add_action( 'add_meta_boxes', 'staff_add_custom_fields' );
  add_action( 'save_post', 'staff_save_custom_fields' );
  }
  
  if( ! function_exists( 'staff_add_custom_fields' ) ) {
    
  function staff_add_custom_fields() {
    
      add_meta_box( 
          'staff_options',
          'Staff Information',
          'staff_inner_custom_field',
          'staff' 
      );
  }
  }
  
  if( ! function_exists( 'staff_inner_custom_field' ) ) {
   
  function staff_inner_custom_field( $post ) {
    // Use nonce for verification
    
    wp_nonce_field( plugin_basename( __FILE__ ), '_Winter' ); 
    get_post_meta($post->ID, 'staff_position', TRUE) ? $staff_position = get_post_meta($post->ID, 'staff_position', TRUE) : $staff_position = '';
    get_post_meta($post->ID, 'staff_link', TRUE) ? $staff_link = get_post_meta($post->ID, 'staff_link', TRUE) : $staff_link = '';
    get_post_meta($post->ID, 'staff_phone', TRUE) ? $staff_phone = get_post_meta($post->ID, 'staff_phone', TRUE) : $staff_phone = '';
    get_post_meta($post->ID, 'staff_email', TRUE) ? $staff_email = get_post_meta($post->ID, 'staff_email', TRUE) : $staff_email = '';
    get_post_meta($post->ID, 'staff_twitter', TRUE) ? $staff_twitter = get_post_meta($post->ID, 'staff_twitter', TRUE) : $staff_twitter = '';
    get_post_meta($post->ID, 'staff_facebook', TRUE) ? $staff_facebook = get_post_meta($post->ID, 'staff_facebook', TRUE) : $staff_facebook = '';
    get_post_meta($post->ID, 'staff_google_plus', TRUE) ? $staff_google_plus = get_post_meta($post->ID, 'staff_google_plus', TRUE) : $staff_google_plus = '';
    get_post_meta($post->ID, 'staff_linkedin', TRUE) ? $staff_linkedin = get_post_meta($post->ID, 'staff_linkedin', TRUE) : $staff_linkedin = '';
    get_post_meta($post->ID, 'staff_youtube', TRUE) ? $staff_youtube = get_post_meta($post->ID, 'staff_youtube', TRUE) : $staff_youtube = '';
    get_post_meta($post->ID, 'staff_rss', TRUE) ? $staff_rss = get_post_meta($post->ID, 'staff_rss', TRUE) : $staff_rss = '';
    get_post_meta($post->ID, 'staff_pinterest', TRUE) ? $staff_pinterest = get_post_meta($post->ID, 'staff_pinterest', TRUE) : $staff_pinterest = '';
    get_post_meta($post->ID, 'staff_skype', TRUE) ? $staff_skype = get_post_meta($post->ID, 'staff_skype', TRUE) : $staff_skype = '';
  ?>
  <table class="form-table">
    <tbody>
      <tr valign="top">
        <th><label for="staff_position">
          <?php _e('Designation:', 'technivo'); ?>
          </label></th>
        <td><input type="text" id="staff_position" name="staff_position" value="<?php echo esc_attr($staff_position); ?>" class="regular-text"/></td>
      </tr>
      <tr valign="top">
        <th><label for="staff_link">
          <?php _e('Link:', 'technivo'); ?>
          </label></th>
        <td><input type="text" id="staff_link" name="staff_link" value="<?php echo esc_attr($staff_link); ?>" class="regular-text" /></td>
      </tr>
      <tr valign="top">
        <th><label for="staff_phone">
          <?php _e('Phone:', 'technivo'); ?>
          </label></th>
        <td><input type="text" id="staff_phone" name="staff_phone" value="<?php echo esc_attr($staff_phone); ?>" class="regular-text" /></td>
      </tr>  <tr valign="top">
        <th><label for="staff_email">
          <?php _e('Email:', 'technivo'); ?>
          </label></th>
        <td><input type="text" id="staff_email" name="staff_email" value="<?php echo esc_attr($staff_email); ?>" class="regular-text" /></td>
      </tr>  <tr valign="top">
        <th><label for="staff_twitter">
          <?php _e('Twitter:', 'technivo'); ?>
          </label></th>
        <td><input type="text" id="staff_twitter" name="staff_twitter" value="<?php echo esc_attr($staff_twitter); ?>" class="regular-text" /></td>
      </tr>  <tr valign="top">
        <th><label for="staff_facebook">
          <?php _e('Facebook:', 'technivo'); ?>
          </label></th>
        <td><input type="text" id="staff_facebook" name="staff_facebook" value="<?php echo esc_attr($staff_facebook); ?>" class="regular-text" /></td>
      </tr>  <tr valign="top">
        <th><label for="staff_google_plus">
          <?php _e('Google Plus:', 'technivo'); ?>
          </label></th>
        <td><input type="text" id="staff_google_plus" name="staff_google_plus" value="<?php echo esc_attr($staff_google_plus); ?>" class="regular-text" /></td>
      </tr>
      <tr valign="top">
        <th><label for="staff_linkedin">
          <?php _e('Linkedin:', 'technivo'); ?>
          </label></th>
        <td><input type="text" id="staff_linkedin" name="staff_linkedin" value="<?php echo esc_attr($staff_linkedin); ?>" class="regular-text" /></td>
      </tr>
      <tr valign="top">
        <th><label for="staff_youtube">
          <?php _e('Youtube:', 'technivo'); ?>
          </label></th>
        <td><input type="text" id="staff_youtube" name="staff_youtube" value="<?php echo esc_attr($staff_youtube); ?>" class="regular-text" /></td>
      </tr>
      <tr valign="top">
        <th><label for="staff_rss">
          <?php _e('Rss:', 'technivo'); ?>
          </label></th>
        <td><input type="text" id="staff_rss" name="staff_rss" value="<?php echo esc_attr($staff_rss); ?>" class="regular-text" /></td>
      </tr>
      <tr valign="top">
        <th><label for="staff_pinterest">
          <?php _e('Pinterest:', 'technivo'); ?>
          </label></th>
        <td><input type="text" id="staff_pinterest" name="staff_pinterest" value="<?php echo esc_attr($staff_pinterest); ?>" class="regular-text" /></td>
      </tr>
      <tr valign="top">
        <th><label for="staff_skype">
          <?php _e('Skype:', 'technivo'); ?>
          </label></th>
        <td><input type="text" id="staff_skype" name="staff_skype" value="<?php echo esc_attr($staff_skype); ?>" class="regular-text" /></td>
      </tr>
      
      
      
    </tbody>
  </table>
  <?php }
  }
  
  if( ! function_exists( 'staff_save_custom_fields' ) ) {
    function staff_save_custom_fields( $post_id ) {
      if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) 
          return;
      if ( !current_user_can( 'edit_post', $post_id ) )
            return;
      $mydata = array();
      foreach($_POST as $key => $data) {
        if($key == '_Winter')
          continue;
        
        if(preg_match('/^staff/i', $key)) {
          $mydata[$key] = $data;
        update_post_meta($post_id, $key, $data); 
        }
      }
    
      return $mydata;
      
    }
  } 
?>
