<?php
namespace Elementor;
/**
 * If this file is called directly, abort.
 */
if (!defined('ABSPATH')) {
    exit;
}
/**
 * Class Product
 */
class Product_Elementor_Widget1 extends Widget_Base {
    // Function for get the slug of the element name.
        public function get_name() {
            return 'wt_top_rated_product';
        }
    // Function for get the name of the element.
        public function get_title() {
            return esc_html__('WT Top Rated Product', WT_DOMAIN);
        }
    // Function for get the icon of the element.
        public function get_icon() {
            return 'eicon-product-images';
        }
    // Function for include element into the category.
        public function get_categories() {
            return ['winter-addon-elements'];
        }
    // Function for include element keywords.
        public function get_keywords() {
            return ['wt_top_rated_product', 'winter-addon-elements'];
        }
    // Funcyion for include css
        public function get_style_depends() {
            return ['top-rated-product'];
        }
        // Adding the controls fields for the Product-category-tab Element
        protected function register_controls() {
            $this->start_controls_section(
                'product_section', array(
                    'label'         => esc_html__('Content', WT_DOMAIN),
                )
            );
            $this->add_control(
                'type', [
                    'label'         => esc_html__('Type', WT_DOMAIN),
                    'type'          => Controls_Manager::SELECT,
                    'options'       => [
                        'grid'		=> esc_html__('Grid', WT_DOMAIN),	
                        'slider'	=> esc_html__('Slider', WT_DOMAIN),
                    ],
                    'default'       => 'grid',
                ]
            );
            $this->add_control(
                'classname',[
                    'label'         => esc_html__('Classname', WT_DOMAIN),
                    'type'          => Controls_Manager::TEXT,
                    'description' 	=> __('classname', WT_DOMAIN),
                ]
            );
            $this->add_control(
                'content',[
                    'label'         => esc_html__('Heading', WT_DOMAIN),
                    'type'          => Controls_Manager::TEXT,
                ]
            );
            $this->add_control(
                'items_per_column', [
                    'label'         => esc_html__('Items Per Column', WT_DOMAIN),
                    'type'          => Controls_Manager::SELECT,
                    'options'       => [
                        '1'		=> esc_html__('1', WT_DOMAIN),
                        '2'		=> esc_html__('2', WT_DOMAIN),
                        '3'		=> esc_html__('3', WT_DOMAIN),
                        '4'		=> esc_html__('4', WT_DOMAIN),
                        '5'		=> esc_html__('5', WT_DOMAIN),
                        '6'		=> esc_html__('6', WT_DOMAIN),
                    ],
                    'default'       => '3',	
                ]
            );
            $this->add_control(
                'items_per_page', [
                    'type'    => Controls_Manager::NUMBER,
                    'label'   => esc_html__( 'Items Per Page', WT_DOMAIN ),
                    'default' => 3,
                    'description' 	=> __('Enter number of items to display per column.', WT_DOMAIN),			
                ]
            );
    }
    /**
     * Render Product Elements widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @access protected
     */
    protected function render() {
        $settings = $this->get_settings();
        global $logotype;
        $items_per_column = $settings['items_per_column'];
        $items_per_page = $settings['items_per_page'];
        $type = $settings['type'];
        $orderby = '';
        $order = '';
        $logotype = $type;	
        // make HTML attribute
        $this->add_render_attribute(
            'wt_top_rated_product_setting',
            [
                'id'                   => 'wt-top-rated-product-' . $this->get_id(),
                'data-page-per-view'   => $items_per_column ,
                'data-slider'          => $type,
            ]
        );
 
        ?>   
        <div class="top-rated-product" <?php echo $this->get_render_attribute_string( 'wt_top_rated_product_setting' ); ?>>
            <div id="woo-products" class="woo-content products_block shop <?php echo $settings['classname']; ?>">       
                <?php if($settings['type'] == "slider") { ?>
                    <div id="<?php echo $items_per_column;?>_woo_carousel" class="woo-carousel top-rat cols-<?php echo $items_per_column; ?>">
                <?php } else { ?>
                    <div id="woo_grid" class="woo-grid cols-<?php echo $items_per_column;?>">
                <?php } ?> 
                    <div class="woo-heading woo-cs-top-product product-grid-container"> <?php echo do_shortcode($settings['content']); 
                        echo do_shortcode('[top_rated_products  per_page="'.$items_per_page.'" Columns="'.$items_per_column.'" orderby="'.$orderby.'" order="'.$order.'" class="test"]'); ?>
                    </div>
                </div>
            </div>
        </div>
    <?php 
    }
}
Plugin::instance()->widgets_manager->register_widget_type(new Product_Elementor_Widget1());