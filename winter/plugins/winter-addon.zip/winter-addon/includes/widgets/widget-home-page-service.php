<?php
namespace Elementor;

/**
 * If this file is called directly, abort.
 */
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Class Home Page Service 
 */
class  Home_Page_Service_Elementor_Widget extends Widget_Base {

    // Function for get the slug of the element name.
        public function get_name() {
            return 'wt_home_page_service';
        }

    // Function for get the name of the element.
        public function get_title() {
            return esc_html__('WT Home Page Service', WT_DOMAIN);
        }

    // Function for get the icon of the element.
        public function get_icon() {
            return 'eicon-settings';
        }

    // Function for include element into the category.
        public function get_categories() {
            return ['winter-addon-elements'];
        }

    // Function for include element keywords.
        public function get_keywords() {
            return ['wt_home_page_service', 'winter-addon-elements'];
        }

    // Funcyion for include css
        public function get_style_depends() {
            return ['wt_home_page_service'];
        }
        
    // Adding the controls fields for the Woo Category Slider
    protected function register_controls() {
        $this->start_controls_section(
            'home_page_service_section', array(
                'label'         => esc_html__('Content', WT_DOMAIN),
            )
        );
        $this->add_control(
            'service_image', [
        'label' => __('Service Image', WT_DOMAIN),
        'type' => Controls_Manager::MEDIA,
        'dynamic' => [
            'active' => true,
        ],
        'default' => [
            'url' => Utils::get_placeholder_image_src(),
        ],
            ]
    );
        
        $this->add_control(
			'dark_service_title',[
				'label'         => esc_html__('Dark Service Title', WT_DOMAIN),
				'type'          => Controls_Manager::TEXT,
                'description' 	=> __('Dark Service Title ex. 24 x 7 free Support', WT_DOMAIN),
			]
		);
        $this->add_control(
			'service_title',[
				'label'         => esc_html__('Service Title', WT_DOMAIN),
				'type'          => Controls_Manager::TEXT,
                'description' 	=> __('Service Title ex. 24 x 7 free Support', WT_DOMAIN),
			]
		);
        $this->add_control(
            'style', [
                'label'         => esc_html__('Type', WT_DOMAIN),
                'type'          => Controls_Manager::SELECT,
                'options'       => [
                    '1'		=> esc_html__('One', WT_DOMAIN),
                    '2'		=> esc_html__('Two', WT_DOMAIN),
                ],
                'description' 	=> __('Select type of Service style.', WT_DOMAIN),
            ]
        );

    }
    /**
     * Render Home Page Service Elements widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @access protected
     */
    protected function render() {
       
        $settings = $this->get_settings();
        
        $home_page_style = $settings['style'];
        $home_page_service_image =$settings['service_image']['url'];
        $home_page_dark_service_title = $settings['dark_service_title'];
        $home_page_service_title = $settings['service_title'];
        ?>
		<div class="service-list service style-<?php echo $home_page_style; ?>">
		    <div class="service-content">
                <div class="back-image">
                    <span class="icon-image" style="background-image:url(<?php echo $home_page_service_image; ?>);"> </span>
                </div>
                <div class="service-icon-content">
                    <div class="dark-service-title">
                        <?php 
                            if(empty($home_page_dark_service_title)){
                                echo "Dark Service Title";
                            }else{
                                echo $home_page_dark_service_title;
                            }
                        ?></div>
                    <span class="service-title"><?php echo $home_page_service_title; ?></span>
		        </div>
		    </div>	
		</div>
        <?php
    }
}
Plugin::instance()->widgets_manager->register_widget_type(new Home_Page_Service_Elementor_Widget());