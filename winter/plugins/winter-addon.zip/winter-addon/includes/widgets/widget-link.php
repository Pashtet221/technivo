<?php
namespace Elementor;

/**
 * If this file is called directly, abort.
 */
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Class WT Multiple Link
 */
class  Multiple_Link_Elementor_Widget extends Widget_Base {

// Function for get the slug of the element name.
    public function get_name() {
        return 'wt_multiple_link';
    }

// Function for get the name of the element.
    public function get_title() {
        return esc_html__('WT Multiple Link', WT_DOMAIN);
    }

// Function for get the icon of the element.
    public function get_icon() {
        return 'eicon-link';
    }

// Function for include element into the category.
    public function get_categories() {
        return ['winter-addon-elements'];
    }

// Function for include element keywords.
    public function get_keywords() {
        return ['wt_multiple_link', 'winter-addon-elements'];
    }

// Funcyion for include css
    public function get_style_depends() {
        return ['wt_multiple_link'];
    }
    
    // Adding the controls fields for the WT Multiple Link
    protected function register_controls() {
        $this->start_controls_section(
            'multiple_link_section', array(
                'label'         => esc_html__('Content', WT_DOMAIN),
            )
        );
        $this->add_control(
			'link_url',[
				'label'         => esc_html__('Link URL', WT_DOMAIN),
				'type'          => Controls_Manager::TEXT,
			]
		);
        $this->add_control(
            'target', [
                'label'         => esc_html__('Button | Target', WT_DOMAIN),
                'type'          => Controls_Manager::SELECT,
                'options'       => [
                    '' 			=> __('Default | _self',WT_DOMAIN),
					'_blank' 	=> __('New Tab or Window | _blank',WT_DOMAIN),
                ],
                'description' 	=> __('Define where to open the linked document', WT_DOMAIN),
            ]
        );
        $this->add_control(
			'content',[
				'label'         => esc_html__('Content', WT_DOMAIN),
				'type'          => Controls_Manager::TEXT,
                'description' 	=> __('HTML tags allowed', WT_DOMAIN),
			]
		);
    }

    /**
     * Render WT Multiple Link Elements widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @access protected
     */
    protected function render() {
        $settings = $this->get_settings();
        if(!empty($settings['link_url'])){?>
		<span class="winter_link"><a href="<?php echo $settings['link_url']; ?>" target="_self"><?php echo do_shortcode($settings['content']); ?><svg width="16px" height="14px"><use xlink:href="#arrowright"></use></svg></a></span>
		<?php } else { ?>
		<li> <?php echo do_shortcode($settings['content']);?></li>
        <?php } 
    }
}
Plugin::instance()->widgets_manager->register_widget_type(new Multiple_Link_Elementor_Widget());