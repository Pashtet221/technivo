<?php
namespace Elementor;

/**
 * If this file is called directly, abort.
 */
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Class Custom_Testimonial
 */
class Custom_Testimonial_Elementor_Widget extends Widget_Base {

    // Function for get the slug of the element name.
        public function get_name() {
            return 'wt_testimonial';
        }

    // Function for get the name of the element.
        public function get_title() {
            return esc_html__('WT Testimonial', WT_DOMAIN);
        }

    // Function for get the icon of the element.
        public function get_icon() {
            return 'eicon-testimonial-carousel';
        }

    // Function for include element into the category.
        public function get_categories() {
            return ['winter-addon-elements'];
        }

    // Function for include element keywords.
        public function get_keywords() {
            return ['wt_testimonial', 'winter-addon-elements'];
        }

    // Funcyion for include css
        public function get_style_depends() {
            return ['testimonial'];
        }

    // Adding the controls fields for the Custom_Testimonial Element
    protected function _register_controls() {
        $this->start_controls_section(
            'product_section', array(
                'label'         => esc_html__('Content', WT_DOMAIN),
            )
        );
        $this->add_control(
            'items_per_column', [
                'label'         => esc_html__('Items Per Column', WT_DOMAIN),
                'type'          => Controls_Manager::SELECT,
                'options'       => [
                    '1'     => esc_html__('1', WT_DOMAIN),
                    '2'     => esc_html__('2', WT_DOMAIN),
                    '3'     => esc_html__('3', WT_DOMAIN),
                ],  
                'default' => 3,

            ]
        );
        $this->add_control(
            'number_of_posts', [
            'type'    => Controls_Manager::NUMBER,
            'label'   => esc_html__( 'Total Testimonial', WT_DOMAIN ),
            'default' => 3,
            'description'   => __('How many total number of items to display. (1,2,3,4..)', WT_DOMAIN ),                
            ]
        );
        $this->end_controls_section();

        $this->start_controls_section(
            'style_sec', [
                'tab'           => Controls_Manager::TAB_STYLE,
                'label' => __( 'Image', WT_DOMAIN ),
            ]
        );

        $this->add_responsive_control(
            'width',[
                'label' => __( 'Image Width', WT_DOMAIN ),
                'type' => Controls_Manager::SLIDER,
                'default' => [
                    'unit' => '%',
                ],
                'tablet_default' => [
                    'unit' => '%',
                ],
                'mobile_default' => [
                    'unit' => '%',
                ],
                'size_units' => [ '%', 'px', 'vw' ],
                'range' => [
                    '%' => [
                        'min' => 1,
                        'max' => 100,
                    ],
                    'px' => [
                        'min' => 1,
                        'max' => 1000,
                    ],
                    'vw' => [
                        'min' => 1,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .testimonial-img' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        
        $this->add_responsive_control(
            'height',
            [
                'label' => __( 'Height', WT_DOMAIN ),
                'type' => Controls_Manager::SLIDER,
                'default' => [
                    'unit' => 'px',
                ],
                'tablet_default' => [
                    'unit' => 'px',
                ],
                'mobile_default' => [
                    'unit' => 'px',
                ],
                'size_units' => [ 'px', 'vh' ],
                'range' => [
                    'px' => [
                        'min' => 1,
                        'max' => 500,
                    ],
                    'vh' => [
                        'min' => 1,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .testimonial-img' => 'height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section();
    }

    /**
     * Render Custom_Testimonial Elements widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @access protected
     */
    protected function render() {
        $settings = $this->get_settings();
        global $post;   
        $args = array(
                'posts_per_page' => $settings['number_of_posts'],
                'post_status' => 'publish',
                'post_type' => 'testimonial',
        );  
        
        // make HTML attribute
        $this->add_render_attribute(
            'wt_custom_testimonial_setting',
            [
                'id'                   => 'wt-custom-testimonial-' . $this->get_id(),
                'data-page-per-view'   => $settings[ 'items_per_column' ],
            ]
        );
        $testimonial_array = get_posts($args);
        $testimonial_count = count($testimonial_array);
        
        if($testimonial_count > 0 ): ?>
            <div class="custom-testimonial" <?php echo $this->get_render_attribute_string( 'wt_custom_testimonial_setting' ); ?>>                       
                <div id="<?php echo $settings['items_per_column']; ?>_testimonial_carousel" class="testimonial-carousel"><?php
                    $temp2 = 0;
                    $i = 0;
                    foreach($testimonial_array as $post) : setup_postdata($post);   
                        get_post_meta($post->ID, 'testimonial_position', TRUE) ? $testimonial_position = get_post_meta($post->ID, 'testimonial_position', TRUE) : $testimonial_position = '';
                        get_post_meta($post->ID, 'testimonial_link', TRUE) ? $testimonial_link = get_post_meta($post->ID, 'testimonial_link', TRUE) : $testimonial_link = '';       
                        $contents = strip_tags(wntr_strip_images($post->post_content));
                        if($i % $settings['items_per_column'] == 1)
                            $class = " first-item"; 
                        elseif($i % $settings['items_per_column'] == 0)
                            $class = " last-item";
                        else
                            $class = ""; ?>
                            
                        <div class="item<?php echo $class;?>">                  
                            <div class="product-block">
                                <div class="custom-testimonial-inner">  
                                   <div class="testimonial-wrapper">
                                    <div class="test-ico"></div>
                                        <div class="testimonial-content">
                                        <div class="testimonial-top"><?php echo get_the_content();?> </div>
                                        </div>
                                            <div class="testi-img">
                                                <div class="testmonial-image">
                                                    <li>
                                                            <?php
                                                            if ( has_post_thumbnail() && ! post_password_required() ) : 
                                                                $post_thumbnail_id = get_post_thumbnail_id();
                                                                $post_thumbnail_url = wp_get_attachment_url( $post_thumbnail_id );
                                                                $image_width ="";
                                                                $image_height="";?>
                                                                    <img class="testimonial-img" src="<?php echo wntr_mr_image_resize($post_thumbnail_url, $image_width, $image_height, true, 'left', false); ?>" title="<?php the_title();?>" alt="<?php the_title(); ?>" />
                                                            <?php else: ?>
                                                                <i class="fa fa-user"></i>
                                                            <?php endif; ?> 
                                                        </li>
                                                <li class="testi_title">
                                                    <div class="testimonial-title"><a title="<?php the_title(); ?>" href="<?php the_permalink();?>" ><?php the_title();?></a></div>
                                                    <?php if(!empty($testimonial_position)):
                                                            if(!empty($testimonial_link)): ?>
                                                    <div class="testimonial-designation"><a href="<?php echo $testimonial_link;?>" ><?php echo $testimonial_position;?></a></div>
                                                </li> 
                                                </div>
                                        </div>
                                    </div>
                                </div>
                                    <?php endif; endif; ?>
                            </div>
                        </div> <?php        
                    endforeach; ?>
                </div>
            </div>
        <?php else: ?>
            <div class="no-result"><?php echo esc_html__('No results found...', 'technivo');?></div>
        <?php endif; 
        wp_reset_query(); 
    }
}
Plugin::instance()->widgets_manager->register_widget_type(new Custom_Testimonial_Elementor_Widget());

