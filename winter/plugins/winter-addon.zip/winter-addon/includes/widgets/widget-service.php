<?php
namespace Elementor;
/**
 * If this file is called directly, abort.
 */
if (!defined('ABSPATH')) {
    exit;
}
/**
 * Class Service
 */
class Service_Elementor_Widget extends Widget_Base {
    // Function for get the slug of the element name.
        public function get_name() {
            return 'wt_service';
        }
    // Function for get the name of the element.
        public function get_title() {
            return esc_html__('WT Service', WT_DOMAIN);
        }
    // Function for get the icon of the element.
        public function get_icon() {
            return 'eicon-cogs';
        }
    // Function for include element into the category.
        public function get_categories() {
            return ['winter-addon-elements'];
        }
    // Function for include element keywords.
        public function get_keywords() {
            return ['wt_service', 'winter-addon-elements'];
        }
    // Funcyion for include css
        public function get_style_depends() {
            return ['wt_service'];
        }
    // Adding the controls fields for the Product-category-tab Element
    protected function register_controls() {
        $this->start_controls_section(
            'service_section', array(
                'label'         => esc_html__('Content', WT_DOMAIN),
            )
        );
        $this->add_control(
            'title',[
                'label'         => esc_html__('Title', WT_DOMAIN),
                'type'          => Controls_Manager::TEXT,
                'description' 	=> __('Service Title', WT_DOMAIN),
                'default'       => 'Title',
            ]
        );
        $this->add_control(
            'style', [
                'label'         => esc_html__('Type', WT_DOMAIN),
                'type'          => Controls_Manager::SELECT,
                'options'       => [
                        '1'		=> esc_html__('One', WT_DOMAIN),
						'2'		=> esc_html__('Two', WT_DOMAIN),
						'3'		=> esc_html__('Three', WT_DOMAIN),
						'4'		=> esc_html__('Four', WT_DOMAIN),
                       
                ],
                'default'       => '1',
            ]
        );
        $this->add_control(
            'icon',[
                'label'         => esc_html__('Icon', WT_DOMAIN),
                'type'          => Controls_Manager::ICONS,
            ]
        );
        $this->add_control(
            'content',[
                'label'         => esc_html__('Content', WT_DOMAIN),
                'type'          => Controls_Manager::TEXT,
                'description' 	=> __('HTML tags allowed', WT_DOMAIN),
            ]
        );
        $this->add_control(
            'link_text',[
                'label'         => esc_html__('Link Text', WT_DOMAIN),
                'type'          => Controls_Manager::TEXT,
            ]
        );
        $this->add_control(
            'link_url',[
                'label'         => esc_html__('Link URL', WT_DOMAIN),
                'type'          => Controls_Manager::TEXT,
            ]
        );
        $this->add_control(
            'target', [
                'label'         => esc_html__('Button | Target', WT_DOMAIN),
                'type'          => Controls_Manager::SELECT,
                'options'       => [
                    '' 			=> __('Default | _self',WT_DOMAIN),
					'_blank' 	=> __('New Tab or Window | _blank',WT_DOMAIN),
                ],
                'description' 	=> __('Define where to open the linked document', WT_DOMAIN),
            ]
        );
        $this->end_controls_section();
         // Start Icon Style Control       
         $this->start_controls_section(
            'icon_setting', [
                'label'         => esc_html__('Icon', WT_DOMAIN),
                'tab'           => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control(
            'icon_color', [
                'label'         => esc_html__('Icon Color', WT_DOMAIN),
                'type'          => Controls_Manager::COLOR,
                'default'       => '#585858',
                'selectors'     => [
                    '{{WRAPPER}} .icon i' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'icon_box_color', [
                'label'         => esc_html__('Icon Background Color', WT_DOMAIN),
                'type'          => Controls_Manager::COLOR,
                'default'       => '#f2f2f2',
                'selectors'     => [
                    '{{WRAPPER}} .icon i' => 'background-color: {{VALUE}};',
                ],
                
            ]
        );
        $this->add_control(
            'icon_size', [
                'label'         => esc_html__('Icon Size', WT_DOMAIN),
                'type'          => Controls_Manager::SLIDER,
                'range'         => [
                    'px'        => [
                        'min'   => 0,
                        'max'   => 200,
                    ],
                ],
                'default'       => ['size'  => 30],
                'selectors'     => [
                    '{{WRAPPER}} .icon i' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section();
    }
     /**
     * Render Service Elements widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @access protected
     */
    protected function render() {
        $settings = $this->get_settings();?>
        	
	    <div class="service hb-animate-element bottom-to-top style-<?php echo $settings['style'];?>">
	        <div class="service-content style-<?php echo $settings['style'];?>"><?php 
                if($settings['style'] == '1' || $settings['style'] == '2'){	
                    if(!empty($settings['icon']))?>
                        <div class="icon"><?php Icons_Manager::render_icon($settings['icon']); ?></div>
                        <div class="service-desc"><?php 
                    if(!empty($settings['title']))?>
                        <div class="title service-text"><?php echo $settings['title'];?></div><?php 
                }	       
                if($settings['style'] == '3'):?>
                    <div class="service-top"><?php
                         if(!empty($settings['icon']))?>
                            <div class="icon"><?php Icons_Manager::render_icon($settings['icon'], [ 'aria-hidden' => 'true' ]); ?></div><?php
                        if(!empty($settings['title']))?>
                            <div class="title service-text"><?php echo $settings['title'];?></div>
                    </div>
                    <div class="service-desc"><?php
                endif;
                if($settings['style'] == '4'):
                    if(!empty($settings['title'])) ?>
                        <div class="title service-text"><?php echo $settings['title'];?></div><?php
                    if(!empty($settings['icon']))?>
                        <div class="icon"><?php Icons_Manager::render_icon($settings['icon']); ?></i></div>
                        <div class="service-desc"><?php
                endif; ?>
                <div class="description other-font"><?php echo do_shortcode($settings['content']);?></div><?php
                if(!empty($settings['link_text'])):
                    if(!empty($settings['link_url'])): ?>
                        <div class="service-read-more other-font"><a href="<?php echo $settings['link_url'];?>" class="other-read-more" target="<?php echo $settings['target'];?>"><?php echo $settings['link_text'];?></a></div> <?php
                    else: ?>
                        <div class="service-read-more other-font"><?php echo $settings['link_text'];?></div><?php
                    endif;
                endif;	?>
            </div>
	    </div>
     </div><?php
    }
}
Plugin::instance()->widgets_manager->register_widget_type(new Service_Elementor_Widget());