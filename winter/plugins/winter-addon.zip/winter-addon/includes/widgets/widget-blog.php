<?php
namespace Elementor;

/**
 * If this file is called directly, abort.
 */
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Class Blog post
 */
class Blogs_Elementor_Widget extends Widget_Base {

// Function for get the slug of the element name.
    public function get_name() {
        return 'wt_blogs';
    }

// Function for get the name of the element.
    public function get_title() {
        return esc_html__('WT Blogs', WT_DOMAIN);
    }

// Function for get the icon of the element.
    public function get_icon() {
        return 'eicon-posts-grid';
    }

// Function for include element into the category.
    public function get_categories() {
        return ['winter-addon-elements'];
    }

// Function for include element keywords.
    public function get_keywords() {
        return ['wt_blogs', 'winter-addon-elements'];
    }

// Funcyion for include css
    public function get_style_depends() {
        return ['wt_blogs'];
    }

// Adding the controls fields for the Blog-post Element
    protected function register_controls() {

    //blog categories 
    $blog_categories = array();
    $categories = get_categories(array(
        'hide_empty' => false,
    ));

    foreach ( $categories as $key => $category ) {
        $blog_categories[$category->term_id] = $category->name;
    }

        $this->start_controls_section(
            'blog_section', array(
                'label'         => esc_html__('Content', WT_DOMAIN),
            )
        );
        $this->add_control(
            'blog_type', [
                'label'         => esc_html__('Type', WT_DOMAIN),
                'type'          => Controls_Manager::SELECT,
                'options'       => [
                    'grid'		=> esc_html__('Grid', WT_DOMAIN),	
					'slider'	=> esc_html__('Slider', WT_DOMAIN),
                ],
                'default'       => 'grid',
            ]
        );
        $this->add_control(
            'items_per_column', [
                'label'         => esc_html__('Items Per Column', WT_DOMAIN),
                'type'          => Controls_Manager::SELECT,
                'options'       => [
                    '1'		=> esc_html__('One', WT_DOMAIN),
                    '2'		=> esc_html__('Two', WT_DOMAIN),
                    '3'		=> esc_html__('Three', WT_DOMAIN),
                    '4'		=> esc_html__('Fourth', WT_DOMAIN),
                ],
                'default' => '3',
            ]
        );
        $this->add_control(
            'number_of_posts', [
            'type'    => Controls_Manager::NUMBER,
            'label'   => esc_html__( 'Total Posts', WT_DOMAIN ),
            'default' => 3,
            'description' => __( 'How many total number of items to display per page. (2,3,4 ..)', WT_DOMAIN ),				
            ]
        );
        $this->add_control(
            'category', [
                 'label' => esc_html__('Categories',WT_DOMAIN),
                 'type' => Controls_Manager::SELECT2,
                 'label_block' => true,
                 'multiple' => true,
                 'description' => esc_html__('Select the categories you want to show',WT_DOMAIN),
                //  'options' => blog_categories(),
                'options'   => $blog_categories,
                 'separator' => 'before',
            ]   
        );
        $this->end_controls_section();

        $this->start_controls_section(
            'style_sec', [
                'tab'           => Controls_Manager::TAB_STYLE,
                'label' => __( 'Image', WT_DOMAIN ),
            ]
        );
        $this->add_responsive_control(
			'width',[
				'label' => __( 'Image Width', WT_DOMAIN ),
				'type' => Controls_Manager::SLIDER,
				'default' => [
					'unit' => '%',
				],
				'tablet_default' => [
					'unit' => '%',
				],
				'mobile_default' => [
					'unit' => '%',
				],
				'size_units' => [ '%', 'px', 'vw' ],
				'range' => [
					'%' => [
						'min' => 1,
						'max' => 100,
					],
					'px' => [
						'min' => 1,
						'max' => 1000,
					],
					'vw' => [
						'min' => 1,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .post-img' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
        
		$this->add_responsive_control(
			'height',
			[
				'label' => __( 'Height', WT_DOMAIN ),
				'type' => Controls_Manager::SLIDER,
				'default' => [
					'unit' => 'px',
				],
				'tablet_default' => [
					'unit' => 'px',
				],
				'mobile_default' => [
					'unit' => 'px',
				],
				'size_units' => [ 'px', 'vh' ],
				'range' => [
					'px' => [
						'min' => 1,
						'max' => 500,
					],
					'vh' => [
						'min' => 1,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .post-img' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);
      
        $this->add_control(
            'img_border_radius', [
        'label' => esc_html__('Border Radius', WT_DOMAIN),
        'type' => Controls_Manager::DIMENSIONS,
        'size_units' => ['px', '%'],
        'selectors' => [
            '{{WRAPPER}} .blog-posts-content .post-image img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
        ],
            ]
    );
    $this->add_group_control(
            Group_Control_Css_Filter::get_type(), [
        'name' => 'thumbnail_filters',
        'selector' => '{{WRAPPER}} .post-img',
            ]
    );

    $this->end_controls_section();
        
    }

    /**
     * Render Blog Elements widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @access protected
     */
    protected function render() {
        $settings = $this->get_settings();
        $linktextvariable = "";

        if (!empty($linkurl) || !empty($linkurl)) {
            $linktextvariable .= '<div class="blog-more-link"><a href=' . $linkurl . '>' . $linktext . '</a></div>';
        }

        if (!empty($settings['category'])) {
            $term_id = $settings['category'];
            $args = array(
                'post_type' => 'post',
                'post_status' => 'publish',
                'posts_per_page' => $settings['number_of_posts'],
                'orderby' => 'date',
                'tax_query' => array(
                    array(
                        'taxonomy' => 'category',
                        'field' => 'id',
                        'terms' => $term_id
                    )
                )
            );
            
        } else {
            $args = array(
                'post_type' => 'post',
                'post_status' => 'publish',
                'posts_per_page' => $settings['number_of_posts'],
                'orderby' => 'date'
            );
        }
        $i = 2;
        wp_reset_postdata();

        $blog_array = new \WP_Query($args);
        $count = $blog_array->post_count;

        // make HTML attribute
        $this->add_render_attribute(
            'wt_blogs_setting',
            [
                'id'                   => 'wt-blogs-' . $this->get_id(),
                'data-page-per-view'   => $settings[ 'items_per_column' ],
                'data-slider'           => $settings['blog_type'],
            ]
        );

        if ($blog_array->have_posts()) {
            ?> <div id="blog-posts-products" class="blog-posts-content posts-content <?php echo $settings['blog_type'];  ?>">
                    <div class="blog-widget"  <?php echo $this->get_render_attribute_string( 'wt_blogs_setting' ); ?>>
               <?php
                global $post ;

                //define variable 
                $class = '';
                $post_day = '';
                $post_month = '';
                $post_year = '';
                $post_author = '';
                $args = '';
                $comments = '';
                $width = '';
                $height = '';

                if ($settings['blog_type'] == "slider") {
                    if ($count > $settings['items_per_column']) {
                        ?>
                        <div id="<?php echo $settings['items_per_column']; ?>_blog_carousel" class="slider blog-carousel blog-cols-<?php echo $settings['items_per_column'];?>">
                    <?php 
                    } else {
                        ?><div id="blog_grid" class="blog-grid grid cols-<?php echo $settings['items_per_column']; ?>">
                        <?php
                    }
                } else { ?>
                    <div id="blog_grid" class="blog-grid grid cols-<?php echo $settings['items_per_column']; ?>">
                <?php 
                }
                    while ($blog_array->have_posts()) { $blog_array->the_post();

                        if ($i % $settings['items_per_column'] == 1) {
                            $class = "first";
                        }else if ($i % $settings['items_per_column'] == 0) {
                            $class = "last";
                        }else {
                            $class = "";
                        }
                        $post_day = get_the_date('d' );
                        $post_month = get_the_date('M');
                        $post_year = get_the_date('Y');
                        $post_author = get_the_author();
                        $args = array(
                            'status' => 'approved',
                            'number' => '5',
                            'post_id' => get_the_ID()
                        );
                        $comments = wp_count_comments(get_the_ID());

                        if (has_post_thumbnail() && !post_password_required()) {
                            $post_thumbnail_id = get_post_thumbnail_id();
                            $image = wp_get_attachment_url($post_thumbnail_id);
                            $width ="";
                            $height ="";
                        } else {
                            $image = get_template_directory_uri() . "/images/webi/placeholder.png";
                        }
                        $src = wntr_mr_image_resize($image, $width, $height, true, 't', false);
                        if (empty($src) || $src == 'image_not_specified') {
                            $src = get_template_directory_uri() . "/images/webi/placeholder.png";
                            $src = wntr_mr_image_resize($src, $width, $height, true, 't', false);
                        }
                        ?>
                        <div class="item container <?php echo $class; ?>"  >
                            <div class="container-inner">
                                <div class="post-image-outer"><div class="post-image">
                                        <img class="post-img" src="<?php echo $src; ?>" title="<?php the_title(); ?>" alt="<?php the_title(); ?>"/>
                                        <div class="block_hover">
                                            <div class="links">				
                                                <a href="<?php echo $image; ?>" class="icon mustang-gallery"><i class="fa fa-plus"></i></a>
                                                <a href="<?php echo get_permalink(); ?>" class="icon"><i class="fa fa-link"></i></a>
                                            </div>
                                        </div>	
                                        													
                                    </div>
                                    <div class="post-by">    
                                        <div class="post-date-outer">
                                        <div class="post-date">
											<div class="blog_month"><?php echo $post_month; ?></div>
											<div class="blog_day"><?php echo $post_day; ?>,</div> 
											<div class="blog_year"><?php echo $post_year; ?></div>
										</div>
                                    </div>  
                                    <div class="blog-author-inner"><span class="author vcard"><a class="url-author" href="" title="" rel="author" tabindex="0"><span>By </span>: admin2022</a></span></div>
                                 </div>
                                </div>

                                <div class="post-content-outer"><div class="post-content-inner">
                                        <div class="post-detail">
                                             <?php
                                            $shorttitle = substr(get_the_title('', '', FALSE), 0, 50);
                                            $stitle = strlen($shorttitle);
                                            if (strlen($shorttitle) >= 50) {
                                                ?>
                                                <div class="post-title">
                                                    <a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php echo $shorttitle; ?></a></div>
                                                <?php
                                            } else {
                                                ?>
                                                <div class="post-title"><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php echo $shorttitle; ?></a></div>
                                            <?php } ?>
                                            <div class="post-description"><?php echo wntr_blog_post_excerpt(100); ?></div>
                                            <div class="blog-read-more"><a class="read-more-link" href="<?php the_permalink(); ?>" title="<?php get_the_title(); ?>"> <?php esc_html__('Read More', 'technivo'); ?>Read More <svg width="18px" height="18px"><use xlink:href="#blognav"></use></svg></a></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php
                    }
                    wp_reset_postdata();
                     $i++;
                    ?>
                        </div>
                        </div>
                    </div>
            <?php } else { ?>
                        <div class="no-result"><?php esc_html__('No results found...', 'technivo') ?></div><?php
                    }
        }
}
Plugin::instance()->widgets_manager->register_widget_type(new Blogs_Elementor_Widget());
        