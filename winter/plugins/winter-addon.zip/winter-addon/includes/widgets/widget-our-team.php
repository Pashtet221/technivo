<?php
namespace Elementor;

/**
 * If this file is called directly, abort.
 */
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Class Our Team
 */
class Our_Team_Elementor_Widget extends Widget_Base {

    // Function for get the slug of the element name.
        public function get_name() {
            return 'wt_our_team';
        }

    // Function for get the name of the element.
        public function get_title() {
            return esc_html__('WT Our Team', WT_DOMAIN);
        }

    // Function for get the icon of the element.
        public function get_icon() {
            return 'eicon-user-circle-o';
        }

    // Function for include element into the category.
        public function get_categories() {
            return ['winter-addon-elements'];
        }

    // Function for include element keywords.
        public function get_keywords() {
            return ['our-team', 'winter-addon-elements'];
        }

    // Funcyion for include css
        public function get_style_depends() {
            return ['our-team'];
        }

    // Adding the controls fields for the Product-category-tab Element
    protected function register_controls() {
        $this->start_controls_section(
            'our_team_section', array(
                'label'         => esc_html__('Content', WT_DOMAIN),
            )
        );
        $this->add_control(
            'items_per_column', [
                'label'         => esc_html__('Items Per Column', WT_DOMAIN),
                'type'          => Controls_Manager::SELECT,
                'options'       => [
                    '1'		=> esc_html__('1', WT_DOMAIN),
                    '2'		=> esc_html__('2', WT_DOMAIN),
                    '3'		=> esc_html__('3', WT_DOMAIN),
                    '4'		=> esc_html__('4', WT_DOMAIN),
                    '5'     => esc_html__('5', WT_DOMAIN),
                ],
                'default'  => '1'
            ]
        );
        $this->add_control(
            'number_of_posts', [
            'type'    => Controls_Manager::NUMBER,
            'label'   => esc_html__( 'Total Posts', WT_DOMAIN ),
            'default' => 3,
            'description' => __( 'How many total number of items to display per page. (2,3,4 ..)', WT_DOMAIN ),				
            ]
        );
    }
    
     /**
     * Render Our Team Elements widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @access protected
     */
    protected function render() {
        $settings = $this->get_settings();
        global $post;	
	$i = 1;
	wp_reset_postdata();
	$args = array(
		'posts_per_page' => $settings['number_of_posts'],
		'post_status' => 'publish',
		'post_type' => 'staff',
		'orderby' => 'date'
	);		
	$team_array = new \WP_Query( $args );
				
	if ( $team_array->have_posts() ): ?>
	    <div id="team-posts-products" class="team-posts-content staff-page posts-content">
            <div id="team_grid" class="team-grid grid cols-<?php echo $settings['items_per_column'];?>">
        <div class="item-our-team"> <?php
	
        while ( $team_array->have_posts() ) : $team_array->the_post();
            get_post_meta(get_the_ID(), 'staff_position', TRUE) ? $staff_position = get_post_meta(get_the_ID(), 'staff_position', TRUE) : $staff_position = '';
            get_post_meta(get_the_ID(), 'staff_link', TRUE) ? $staff_link = get_post_meta(get_the_ID(), 'staff_link', TRUE) : $staff_link = '';
            get_post_meta(get_the_ID(), 'staff_phone', TRUE) ? $staff_phone = get_post_meta(get_the_ID(), 'staff_phone', TRUE) : $staff_phone = '';
            get_post_meta(get_the_ID(), 'staff_email', TRUE) ? $staff_email = get_post_meta(get_the_ID(), 'staff_email', TRUE) : $staff_email = '';
            get_post_meta(get_the_ID(), 'staff_twitter', TRUE) ? $staff_twitter = get_post_meta(get_the_ID(), 'staff_twitter', TRUE) : $staff_twitter = '';
            get_post_meta(get_the_ID(), 'staff_facebook', TRUE) ? $staff_facebook = get_post_meta(get_the_ID(), 'staff_facebook', TRUE) : $staff_facebook = '';
            // get_post_meta(get_the_ID(), 'staff_google_plus', TRUE) ? $staff_google_plus = get_post_meta(get_the_ID(), 'staff_google_plus', TRUE) : $staff_google_plus = '';
            get_post_meta(get_the_ID(), 'staff_linkedin', TRUE) ? $staff_linkedin = get_post_meta(get_the_ID(), 'staff_linkedin', TRUE) : $staff_linkedin = '';
            get_post_meta(get_the_ID(), 'staff_youtube', TRUE) ? $staff_youtube = get_post_meta(get_the_ID(), 'staff_youtube', TRUE) : $staff_youtube = '';
            get_post_meta(get_the_ID(), 'staff_rss', TRUE) ? $staff_rss = get_post_meta(get_the_ID(), 'staff_rss', TRUE) : $staff_rss = '';
            get_post_meta(get_the_ID(), 'staff_pinterest', TRUE) ? $staff_pinterest = get_post_meta(get_the_ID(), 'staff_pinterest', TRUE) : $staff_pinterest = '';
            get_post_meta(get_the_ID(), 'staff_skype', TRUE) ? $staff_skype = get_post_meta(get_the_ID(), 'staff_skype', TRUE) : $staff_skype = ''; 
            
            $s = 0; 
            if(!empty($staff_link)) $s++;
            if(!empty($staff_email)) $s++; 
            if(!empty($staff_twitter)) $s++; 
            if(!empty($staff_facebook)) $s++; 
            // if(!empty($staff_google_plus)) $s++; 
            if(!empty($staff_linkedin)) $s++; 
            if(!empty($staff_youtube)) $s++; 
            if(!empty($staff_rss)) $s++; 
            if(!empty($staff_pinterest)) $s++; 
            if(!empty($staff_skype)) $s++;	
            if($i % $settings['items_per_column'] == 1 )
                $class = " first";
            elseif($i % $settings['items_per_column'] == 0 )
                $class = " last";
            else
                $class = "";
            if ( has_post_thumbnail() && ! post_password_required() ) :	
                $post_thumbnail_id = get_post_thumbnail_id();
                $image = wp_get_attachment_url( $post_thumbnail_id );
            else:
                $image = get_template_directory_uri()."/images/webi/placeholder.png";
            endif;
            $src = wntr_mr_image_resize($image, 600, 600, true, 't', false);
            if( empty ( $src ) || $src == 'image_not_specified' ):
                $src = get_template_directory_uri()."/images/webi/placeholder.png";
                $src = wntr_mr_image_resize($src, 600, 600, true, 't', false);
            endif; ?>
                <article class="item container<?php echo $class;?>">
                    <div class="single-team container-inner">
                        <div class="staff-image">
                            <img src="<?php echo $src; ?>" title="<?php the_title();?>" alt="<?php the_title();?>" />
                            <div class="staff-image-hover"></div>
                        </div>	
                        <div class="staff-content"><?php
                            $shorttitle = substr(the_title('','',FALSE),0,150); ?>
                            <div class="team-content-box"><?php
                                if(!empty($staff_position) && $staff_position != '')?>
                                <div class="staff-position"><span><?php echo $staff_position;?></span></div><?php
                                if(!empty($shorttitle) && $shorttitle != '') ?>
                                    <div class="staff-name"><a title="<?php the_title();?>" href="<?php the_permalink();?>"><?php echo $shorttitle;?></a></div>
                                    <div class="staff-social icon-<?php echo $s;?>"><?php
                                        if(!empty($staff_link) && $staff_link != ''){ ?>
                                        <a href="<?php echo $staff_link;?>" title="Website" class="website icon"><i class="fa fa-link"></i></a><?php
                                        } if(!empty($staff_email) && $staff_email != '') { ?>
                                        <a href="mailto:<?php echo $staff_email;?>" title="Email" class="email icon"><i class="fa fa-envelope-o"></i></a><?php
                                        } if(!empty($staff_twitter) && $staff_twitter != '') { ?>
                                        <a href="<?php echo $staff_twitter;?>" title="Twitter" class="twitter icon"><svg class="icon icon-twitter" viewBox="0 0 16 14" xmlns="http://www.w3.org/2000/svg">
  <path d="M0.168061 0L5.94314 7.72183L0.131592 14H1.43954L6.52754 8.50337L10.6385 14H15.0895L8.98948 5.84383L14.3988 0H13.0909L8.40509 5.06229L4.61905 0H0.168061ZM2.09149 0.963435H4.13629L13.1658 13.0364H11.121L2.09149 0.963435Z" fill="currentcolor"></path>
</svg></a><?php
                                        } if(!empty($staff_facebook) && $staff_facebook != '') { ?>
                                        <a href="<?php echo $staff_facebook;?>" title="Facebook" class="facebook icon"><i class="fa fa-facebook"></i></a><?php
                                        } if(!empty($staff_linkedin) && $staff_linkedin != '') { ?>
                                        <a href="<?php echo $staff_linkedin;?>" title="Linkedin" class="linkedin icon"><i class="fa fa-linkedin"></i></a><?php
                                        } if(!empty($staff_youtube) && $staff_youtube != '') { ?>
                                        <a href="<?php echo $staff_youtube;?>" title="Youtube" class="youtube icon"><i class="fa fa-youtube"></i></a><?php
                                        } if(!empty($staff_rss) && $staff_rss != '') { ?>
                                        <a href="<?php echo $staff_rss;?>" title="RSS" class="rss icon"><i class="fa fa-rss"></i></a><?php
                                        } if(!empty($staff_pinterest) && $staff_pinterest != '') { ?>
                                        <a href="<?php echo $staff_pinterest;?>" title="Pinterest" class="pinterest icon"><i class="fa fa-pinterest"></i></a><?php
                                        } if(!empty($staff_skype) && $staff_skype != '') { ?>
                                        <a href="<?php echo $staff_skype; ?>" title="Skype" class="skype icon"><i class="fa fa-skype"></i></a>
                                    <?php } ?>
                                    </div>
                            </div>
                        </div>
                    </div>
                </article> <?php
            $i++;
        endwhile; ?>
        </div> <?php
	    wp_reset_postdata(); ?>
	</div></div> <?php
	else: ?>
	<div class="no-result"><?php esc_html__('No results found...', 'technivo') ;?></div><?php
	endif; 
    }
}

Plugin::instance()->widgets_manager->register_widget_type(new Our_Team_Elementor_Widget());