<?php
namespace Elementor;

/**
 * If this file is called directly, abort.
 */
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Class  WT Pricing Table
 */
class  Pricing_Table_Elementor_Widget extends Widget_Base {

// Function for get the slug of the element name.
    public function get_name() {
        return 'wt-pricing-table';
    }

// Function for get the name of the element.
    public function get_title() {
        return esc_html__('WT Pricing Table', WT_DOMAIN);
    }

// Function for get the icon of the element.
    public function get_icon() {
        return 'eicon-price-table';
    }

// Function for include element into the category.
    public function get_categories() {
        return ['winter-addon-elements'];
    }

// Function for include element keywords.
    public function get_keywords() {
        return ['wt-pricing-table', 'winter-addon-elements'];
    }

// Funcyion for include css
    public function get_style_depends() {
        return ['wt-pricing-table'];
    }

    // Adding the controls fields for the WT Pricing Table Element
    protected function register_controls() {
        $this->start_controls_section(
            'pricing_table_section', array(
                'label'         => esc_html__('Content', WT_DOMAIN),
            )
        );
        $this->add_control(
			'heading',[
				'label'         => esc_html__('Title', WT_DOMAIN),
				'type'          => Controls_Manager::TEXT,
                'default'			=> 'Title',
			]
		);
        $this->add_control(
            'selected', [
                'label'         => esc_html__('Featured', WT_DOMAIN),
                'type'          => Controls_Manager::SELECT,
                'options'       => [
                    'no'		=> __('No', WT_DOMAIN),
                    'yes'		=> __('Yes', WT_DOMAIN),
                ],
            ]
        );
        $this->add_control(
			'button_text',[
				'label'         => esc_html__('Button Text', WT_DOMAIN),
				'type'          => Controls_Manager::TEXT,
                'description' 	=> __('Read More', WT_DOMAIN),
                'default'			=> 'Read More',
			]
		);
        $this->add_control(
			'button_link',[
				'label'         => esc_html__('Button Link', WT_DOMAIN),
				'type'          => Controls_Manager::TEXT,
                'description' 	=> __('Link will appear only if this field will be filled.', WT_DOMAIN),
			]
		);
        $this->add_control(
            'target', [
                'label'         => esc_html__('Button | Target', WT_DOMAIN),
                'type'          => Controls_Manager::SELECT,
                'options'       => [
                    '' 			=> __('Default | _self',WT_DOMAIN),
					'_blank' 	=> __('New Tab or Window | _blank',WT_DOMAIN),
                ],
                'description' 	=> __('Define where to open the linked document', WT_DOMAIN),
            ]
        );
        $this->add_control(
			'price',[
				'label'         => esc_html__('Price', WT_DOMAIN),
				'type'          => Controls_Manager::TEXT,
                'default'			=> '$500',
               
			]
		);
        $this->add_control(
			'price_per',[
				'label'         => esc_html__('Price for period', WT_DOMAIN),
				'type'          => Controls_Manager::TEXT,
                'default'			=> 'Month',
			]
		);
        $this->add_control(
			'content',[
				'label'         => esc_html__('Content', WT_DOMAIN),
				'type'          => Controls_Manager::TEXT,
                'description' 	=> __('HTML tags allowed', WT_DOMAIN),
                'default'			=> '<ul><li><strong>List</strong> item</li></ul>',
			]
		);

    }
    /**
     * Render WT Pricing Table Elements widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @access protected
     */
    protected function render() {
        $settings = $this->get_settings();

        if($settings['selected'] == 'yes'){
            $settings['selected'] = 'selected';
        }?>
        <div class="pricing_wrapper">
            <div class="pricing_wrapper_inner <?php echo $settings['selected'];?>">
                <?php if($settings['heading'] != '' && $settings['price_per'] != '' && $settings['price'] != '') { ?>
                    <div class="pricing_heading"><?php echo $settings['heading']; ?></div>
                    <div class="pricing_top">
                    <div class="pricing_per"><?php echo $settings['price_per']; ?></div>
                    <div class="pricing_price"><?php echo $settings['price']; ?></div></div>
                <?php } 	
                else{ ?>
                    <div class="nopricing_heading"></div>
                    <div class="nopricing_top"><div class="pricing_per"></div><div class="pricing_price"></div></div>
                <?php } ?>
                <div class="pricing_bottom">
                    <ul><?php echo do_shortcode($settings['content']);?></ul>
                    <div class="pricing_button">
                        <?php if($settings['button_text'] != '') { ?>
                            <a href="<?php echo $settings['button_link']; ?>" target="<?php echo $settings['target']; ?>" class="button" id="pricing-btn"><?php echo $settings['button_text'];?></a>
                        <?php } ?> 
                    </div>
                </div>
            </div>
        </div><?php
    }
}
Plugin::instance()->widgets_manager->register_widget_type(new Pricing_Table_Elementor_Widget());