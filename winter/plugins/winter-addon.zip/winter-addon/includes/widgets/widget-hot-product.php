<?php

namespace Elementor;

/**
 * If this file is called directly, abort.
 */
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Class Call to Action
 */
class Hot_Product_Elementor_Widget extends Widget_Base {

// Function for get the slug of the element name.
    public function get_name() {
        return 'wt_hot_product';
    }

// Function for get the name of the element.
    public function get_title() {
        return esc_html__('WT Hot Product', WT_DOMAIN);
    }

// Function for get the icon of the element.
    public function get_icon() {
        return 'eicon-products';
    }

// Function for include element into the category.
    public function get_categories() {
        return ['winter-addon-elements'];
    }

// Function for include element keywords.
    public function get_keywords() {
        return ['wt_hot_product', 'winter-addon-elements'];
    }

// Funcyion for include css
    public function get_style_depends() {
        return ['wt_hot_product'];
    }

// Adding the controls fields for the Blog-post Element
    
    protected function register_controls() {

        $this->start_controls_section(
            'product_section', array(
                'label'         => esc_html__('Content', WT_DOMAIN),
            )
        );
        $this->add_control(
            'total_product', [
                'type'    => Controls_Manager::NUMBER,
                'label'   => esc_html__( 'Total Product', WT_DOMAIN ),
                'default' => 3,
                'description' => __( 'How many total number of product to display.', WT_DOMAIN ),				
            ]
        );
        $this->add_control(
            'excerpt_length', [
            'label' => __('Excerpt Length', WT_DOMAIN),
            'type' => Controls_Manager::NUMBER,
            'default' => apply_filters('excerpt_length', 25),
            ]
        );
        $this->end_controls_section();
            
        $this->start_controls_section(
            'style_sec', [
                'tab'           => Controls_Manager::TAB_STYLE,
                'label' => __( 'Image', WT_DOMAIN ),
            ]
        );
        $this->add_responsive_control(
			'width',[
				'label' => __( 'Image Width', WT_DOMAIN ),
				'type' => Controls_Manager::SLIDER,
				'default' => [
					'unit' => '%',
				],
				'tablet_default' => [
					'unit' => '%',
				],
				'mobile_default' => [
					'unit' => '%',
				],
				'size_units' => [ '%', 'px', 'vw' ],
				'range' => [
					'%' => [
						'min' => 1,
						'max' => 100,
					],
					'px' => [
						'min' => 1,
						'max' => 1000,
					],
					'vw' => [
						'min' => 1,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .product-img' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
        
		$this->add_responsive_control(
			'height',
			[
				'label' => __( 'Height', WT_DOMAIN ),
				'type' => Controls_Manager::SLIDER,
				'default' => [
					'unit' => 'px',
				],
				'tablet_default' => [
					'unit' => 'px',
				],
				'mobile_default' => [
					'unit' => 'px',
				],
				'size_units' => [ 'px', 'vh' ],
				'range' => [
					'px' => [
						'min' => 1,
						'max' => 500,
					],
					'vh' => [
						'min' => 1,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .product-img' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);
        $this->add_control(
            'img_border_radius', [
                'label' => esc_html__('Border Radius', WT_DOMAIN),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} .product-img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_group_control(
                Group_Control_Css_Filter::get_type(), [
            'name' => 'thumbnail_filters',
            'selector' => '{{WRAPPER}} .product-img',
                ]
        );

     $this->end_controls_section();
}

    /**
     * Render Call to Action Elements widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @access protected
     */
    protected function render() {
        $settings = $this->get_settings();
        global $product;
        $params = array(
            'posts_per_page' => $settings['total_product'],
            'post_type' => 'product',
        );
        $wc_query = new \WP_Query($params); 
        
         // make HTML attribute
        $this->add_render_attribute(
            'wt_hot_product_setting',
            [
                'id'  => 'wt-product-slider-' . $this->get_id(),

            ]
        ); 
        ?>
<div class="wt-hot-products" <?php echo $this->get_render_attribute_string( 'wt_hot_product_setting' ); ?> >
	<div id="home_featured_carousel">
		<div class="home-featured-carousel owl-carousel woocommerce single-product products">
			<?php if ($wc_query->have_posts()) {
            while ($wc_query->have_posts()) : $wc_query->the_post();
            global $product;
            $today = date('Y-m-d');
            $sale_price_dates_from = ( $date = get_post_meta(get_the_ID(), '_sale_price_dates_from', true) ) ? date_i18n('Y-m-d', $date) : '';
            $sale_price_dates_to = ( $date = get_post_meta(get_the_ID(), '_sale_price_dates_to', true) ) ? date_i18n('Y-m-d', $date) : '';

            if ($today >= $sale_price_dates_from && $today <= $sale_price_dates_to) {
                if ($sale_price_dates_to != "") {
                    global $product;
                    $rating = $product->get_average_rating();
                    $attachment_ids = $product->get_gallery_image_ids();
                    ?>
				<div class="item">
					<div class="feature-inner">
						<div class="feature-image-wrapper">
							<?php if ($product->is_on_sale()) { ?> <span class="onsale"><?php echo esc_html('Sale', 'woocommerce') ?></span>
								<?php } ?>
									<div class="images">
										<?php
                                        if (has_post_thumbnail()) {
                                            $image_caption = get_post(get_post_thumbnail_id())->post_excerpt;
                                            $image_link = wp_get_attachment_url(get_post_thumbnail_id());
                                            $image = get_the_post_thumbnail(get_the_ID(), apply_filters('single_product_large_thumbnail_size', 'shop_single'), array(
                                                'title' => get_the_title(get_post_thumbnail_id())
                                            ));
                                            ?> <a href="<?php echo get_permalink(); ?>">
                                                <img class="product-img" alt="<?php get_the_title(); ?>" src="<?php echo $image_link; ?>" />
                                            </a>
											<?php } ?>
									</div>
						</div>
						<div class="product-detail">
							<h1 class="product_title">
                                        <a href="<?php the_permalink(); ?>">
                                            <?php the_title(); ?></a>
                                    </h1>
							<div class="woocommerce-product-star">
								<?php echo wc_get_rating_html($rating); ?>
							</div>
							<div class="product-price price">
								<?php echo $product->get_price_html(); ?>
							</div>
							<div class="product-description">
								<?php echo wntr_excerpt($settings['excerpt_length']);?>
							</div>
                            <div class="count-down">
								<div class="countbox hastime" data-time="<?php echo $sale_price_dates_to; ?>"> </div>
							</div>
                            <div class="product-block-outer"><div class="product-block-hover"></div></div>
							<div class="hot-btn">
							<?php do_action( 'woocommerce_after_shop_loop_item' ); ?>
							<div class="pro-btn"></div>
                        </div>
						</div>
					</div>
				</div>
				<?php
                        }
                    }
                endwhile;
            wp_reset_postdata();
                    }
                    ?>
		</div>
	</div>
</div>
	<?php
    }
}
Plugin::instance()->widgets_manager->register_widget_type(new Hot_Product_Elementor_Widget());