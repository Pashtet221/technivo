<?php
namespace Elementor;

/**
 * If this file is called directly, abort.
 */
if (!defined('ABSPATH')) { 
    exit;
}

/**
 * Class Product
 */
class Product_With_Tab_Elementor_Widget extends Widget_Base {

    // Function for get the slug of the element name.
        public function get_name() {
            return 'wt_product_with_tab';
        }

    // Function for get the name of the element.
        public function get_title() {
            return esc_html__('WT Product With Tab', WT_DOMAIN);
        }

    // Function for get the icon of the element.
        public function get_icon() {
            return 'eicon-product-images';
        }

    // Function for include element into the category.
        public function get_categories() {
            return ['winter-addon-elements'];
        }

    // Function for include element keywords.
        public function get_keywords() {
            return ['wt_product_with_tab', 'winter-addon-elements'];
        }

    // Funcyion for include css
        public function get_style_depends() {
            return ['wt-product-with-tab'];
        }

        // Adding the controls fields for the Product-category-tab Element
        protected function register_controls() {

            $this->start_controls_section(
                'product_section', array(
                    'label'         => esc_html__('Content', WT_DOMAIN),
                )
            );
            $this->add_control(
                'type', [
                    'label'         => esc_html__('Type', WT_DOMAIN),
                    'type'          => Controls_Manager::SELECT,
                    'options'       => [
                        'grid'      => esc_html__('Grid', WT_DOMAIN),   
                        'slider'    => esc_html__('Slider', WT_DOMAIN),
                    ],
                    'default'       => 'grid',
                ]
            );
            $this->add_control(
                'content',[
                    'label'         => esc_html__('Heading', WT_DOMAIN),
                    'type'          => Controls_Manager::TEXT,
                ]
            ); 
            $this->add_control(
                'items_per_column', [
                    'label'         => esc_html__('Items Per Column', WT_DOMAIN),
                    'type'          => Controls_Manager::SELECT,
                    'options'       => [
                        '1'     => esc_html__('1', WT_DOMAIN),
                        '2'     => esc_html__('2', WT_DOMAIN),
                        '3'     => esc_html__('3', WT_DOMAIN),
                        '4'     => esc_html__('4', WT_DOMAIN),
                        '5'     => esc_html__('5', WT_DOMAIN),
                        '6'     => esc_html__('6', WT_DOMAIN),
                    ],
                    'default'       => '3', 
                ]
            );
            $this->add_control(
                'items_per_page', [
                    'type'    => Controls_Manager::NUMBER,
                    'label'   => esc_html__( 'Items Per Page', WT_DOMAIN ),
                    'default' => 3,
                    'description'   => __('Enter number of items to display per column.', WT_DOMAIN),           
                ]
            );
            $this->add_control(
                'categories', [
                     'label' => esc_html__('Product Types',WT_DOMAIN),
                     'type' => Controls_Manager::SELECT2,
                     'label_block' => true,
                     'multiple' => true,
                     'description' => esc_html__('Select the product type you want to show', WT_DOMAIN),
                     'options' => [
                                    'featured' => __( 'Featured', WT_DOMAIN ),
                                    'bestselling' => __( 'Best Selling', WT_DOMAIN ),
                                    'latest' => __( 'Latest', WT_DOMAIN ),
                                    'Top Rated' => __( 'Top Rated', WT_DOMAIN ),
                                ],
                    'default' => [ 'featured', 'bestselling', 'latest'],
                    // 'separator' => 'before',
                ]   
           );
    }
    
    /**
     * Render Product Elements widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @access protected
     */
    protected function render() {
        $settings = $this->get_settings();
        global $logotype;
        $items_per_column = $settings['items_per_column'];
        $items_per_page = $settings['items_per_page'];
        $type = $settings['type'];
        $product_tab = $settings['categories'];
        $logotype = $type;  

        $product_tab_count = count($settings['categories']);

        
        // make HTML attribute
        $this->add_render_attribute(
            'wt_product_with_tab_setting',
            [
                'id'                   => 'wt-product-with-tab-' . $this->get_id(),
                'data-page-per-view'   => $settings[ 'items_per_column' ],
                'data-slider'          => $settings['type'],
                'data-tab'             => $product_tab_count
            ]
        );
        ?>       
        <div 
            <?php echo  $this->get_render_attribute_string( 'wt_product_with_tab_setting' ); ?>  
            class="product-with-tab" 
        >
            <?php if(!empty($product_tab)){ ?>
                <div  class="woo-products-tabs woo-content products_block shop ">       
                    <div class="product-tab-filter">
                        <ul class="filter-list-main">
                            <?php                          
                                foreach ( $product_tab as $tab ) { 
                                    echo '<li class="filter-item"><div class="tab-title">'. $tab .'</div></li>';
                                }
                            ?>
                        </ul>
                    </div>
                    <?php if($settings['type'] == "slider") { ?>
                        <div id="<?php echo $items_per_column;?>_woo_carousel" class="woo-carousel best_sell cols-<?php echo $items_per_column; ?>">
                    <?php } else { ?>
                        <div id="woo_grid" class="woo-grid cols-<?php echo $items_per_column;?>">
                    <?php } ?> 
                        <div class="woo-heading woo-cs-top-product product-grid-container"> 
                            <?php 
                            foreach ( $product_tab as $tab ) {
                                if( $tab == 'featured'){
                                    ?>
                                        <div class="featured-main woofeature filter-div" >
                                            <?php echo do_shortcode('[featured_products  per_page="'.$items_per_page.'" columns="'.$items_per_column.'" ]'); ?>
                                        </div>
                                    <?php
                                }
                                if($tab == 'bestselling' ){
                                    ?>
                                        <div class="bestselling-main woonew filter-div" >
                                            <?php echo do_shortcode('[best_selling_products  per_page="'.$items_per_page.'" columns="'.$items_per_column.'" ]'); ?>
                                        </div>
                                    <?php
                                }
                                if( $tab == 'latest'){
                                    ?>
                                        <div class="latest-main woobest filter-div " >
                                            <?php echo do_shortcode('[recent_products  per_page="'.$items_per_page.'" columns="'.$items_per_column.'" ]'); ?>
                                        </div>
                                    <?php       
                                }
                                if( $tab == 'Top Rated'){
                                    ?>
                                        <div class="top-rated-main woosale filter-div " >
                                            <?php echo do_shortcode('[top_rated_products  per_page="'.$items_per_page.'" columns="'.$items_per_column.'" ]'); ?>
                                        </div>
                                    <?php       
                                }
                            }
                            ?>
                        </div>
                    </div>
                </div>
            <?php
                }else{
                    echo '<b>' .  __( 'Please select product types.', WT_DOMAIN ) . '</b>';
                }
            ?>
        </div>
        <?php 
    }
}
Plugin::instance()->widgets_manager->register_widget_type(new Product_With_Tab_Elementor_Widget());