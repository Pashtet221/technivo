<?php
namespace Elementor;

/**
 * If this file is called directly, abort.
 */
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Class Call to Action
 */
class Product_category_Elementor_Widget extends Widget_Base {

    // Function for get the slug of the element name.
        public function get_name() {
            return 'wt_product_category_tab';
        }

    // Function for get the name of the element.
        public function get_title() {
            return esc_html__('WT Product Category Tab', WT_DOMAIN);
        }

    // Function for get the icon of the element.
        public function get_icon() {
            return 'eicon-product-tabs';
        }

    // Function for include element into the category.
        public function get_categories() {
            return ['winter-addon-elements'];
        }

    // Function for include element keywords.
        public function get_keywords() {
            return ['wt_product_category_tab', 'winter-addon-elements'];
        }

    // Funcyion for include css
        public function get_style_depends() {
            return ['product-category-tab'];
        }

        // Adding the controls fields for the Product-category-tab Element
    protected function register_controls() {
        $this->start_controls_section(
            'product_category_tab_section', array(
                'label'         => esc_html__('Content', WT_DOMAIN),
            )
        );
        $this->add_control(
            'type', [
                'label'         => esc_html__('Type', WT_DOMAIN),
                'type'          => Controls_Manager::SELECT,
                'options'       => [
                    'grid'		=> esc_html__('Grid', WT_DOMAIN),	
					'slider'	=> esc_html__('Slider', WT_DOMAIN),
                ],
                'default'       => 'grid',
            ]
        );
        $this->add_control(
            'items_per_column', [
                'label'         => esc_html__('Items Per Column', WT_DOMAIN),
                'type'          => Controls_Manager::SELECT,
                'options'       => [
                    '2'		=> esc_html__('2', WT_DOMAIN),
                    '3'		=> esc_html__('3', WT_DOMAIN),
                    '4'		=> esc_html__('4', WT_DOMAIN),
                    '5'		=> esc_html__('5', WT_DOMAIN),
                ],
                'default'       => '3',
            ]
        );
        $this->add_control(
            'items_per_page', [
            'type'    => Controls_Manager::NUMBER,
            'label'   => esc_html__( 'Items Per Page', WT_DOMAIN ),
            'default' => 3,
            'description' 	=> __('Enter number of items to display per column.', WT_DOMAIN),			
            ]
        );
        $this->add_control(
            'categories', [
                 'label' => esc_html__('Categories',WT_DOMAIN),
                 'type' => Controls_Manager::SELECT2,
                 'label_block' => true,
                 'multiple' => true,
                 'description' => esc_html__('Select the categories you want to show',WT_DOMAIN),
                 'options' => woo_product_categories(),
                 'separator' => 'before',
            ]   
       );
    }

    /**
     * Render Category Tab Elements widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @access protected
     */
    protected function render() {
        $settings = $this->get_settings();
        $category_ids_array = $settings['categories'];
        $items_per_column = $settings['items_per_column'];
        $items_per_page = $settings['items_per_page'];
        $type = $settings['type'];
        $image = "";
        $width = "" ;
        $height ="";
        $src = wntr_mr_image_resize($image, $width, $height, true, 't', false);
       
        // make HTML attribute
        $this->add_render_attribute(
            'wt_product_category_tab_setting',
            [
                'id'                   => 'wt-product-category-tab-' . $this->get_id(),
                'data-page-per-view'   => $items_per_column,
                'data-slider'          => $type ,
            ]
        );
        if(!empty($category_ids_array)){
        ?>
        <div class="product-category-tab" <?php echo $this->get_render_attribute_string( 'wt_product_category_tab_setting' ); ?>>        
            <div id="categorytab"><?php
                $category_ids = '';
                $term_category_id = '';
                $term_category_name = '';
                $term_categroy_slug = '';
                $term_thumbnai_id = '';
                $term_image = '';?>		
                <div class="cate-list title-outer"></div>
                <ul class="resp-tabs-list toggle-block"><?php    
                foreach($category_ids_array as $key){
                        $category_ids = get_term( $key, 'product_cat' );
                        if($category_ids){
                            $term_category_id = $category_ids->term_id;
                            $term_category_name = $category_ids->name;
                            $term_category_slug = $category_ids->slug;
                            $term_thumbnail_id =  get_term_meta( $term_category_id , 'thumbnail_id', true );	 	
                            $term_image = wp_get_attachment_url( $term_thumbnail_id );?> 
                            <li><a class="cat-img"><img src="<?php echo $term_image; ?>"/></a>
                            <div class="tab-title"><?php echo $term_category_name; ?></div></li>
                        <?php }
                    }?>
                </ul>
                <div class="resp-tabs-container <?php echo $type; ?> woo-cs-product-cat"><?php
                        foreach($category_ids_array as $key){
                        $term_array = get_term( $key, 'product_cat' );
                        $term_category_id = isset($term_array->term_id) ? $term_array->term_id : '';
                        $term_category_slug = isset($term_array->slug) ? $term_array->slug : ''; ?>
                        <div id="woo-products-var" class="woo-content products_block shop">       
                            <?php if($settings['type'] == "slider") { ?>
                                <div id="<?php echo $items_per_column;?>_woo_slick" class="woo-slick cat cols-<?php echo $items_per_column; ?>">
                                <?php } else { ?>
                            <div id="woo_grid" class="woo-grid cols-<?php echo $items_per_column;?>">
                                <?php } ?> 
                                <div class="woo-heading product-grid-container">
                                <?php echo do_shortcode('[product_category  per_page="'.$items_per_page.'" Columns="'.$items_per_column.'" category="'.$term_category_slug.'"]'); ?>
                                </div> 
                            </div>
                        </div> <?php 
                     } ?>
                </div>
            </div>
        </div>
    <?php
        }else{
            echo '<b>' .  __( 'Please Select Categories.', WT_DOMAIN ) . '</b>';
        }
    }

}
Plugin::instance()->widgets_manager->register_widget_type(new Product_category_Elementor_Widget());
