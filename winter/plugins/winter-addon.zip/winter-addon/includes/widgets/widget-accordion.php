<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Elementor accordion widget.
 *
 * Elementor widget that displays a collapsible display of content in an
 * accordion style, showing only one item at a time.
 *
 * @since 1.0.0
 */
class Accordion_Elementor_Widget extends Widget_Base {

    // Function for get the slug of the element name.
    public function get_name() {
        return 'wt_accordion';
    }

    // Function for get the name of the element.
    public function get_title() {
        return esc_html__('WT Accordion', WT_DOMAIN);
    }

    // Function for get the icon of the element.
    public function get_icon() {
        return 'eicon-accordion';
    }

    // Function for include element into the category.
    public function get_categories() {
        return ['winter-addon-elements'];
    }

    // Function for include element keywords.
    public function get_keywords() {
        return ['accordion', 'winter-addon-elements'];
	}

    // Funcyion for include css
    public function get_style_depends()
    {
        return ['accordion'];
    }

	/**
	 * Register accordion widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 3.1.0
	 * @access protected
	 */
	protected function register_controls() {

		$this->start_controls_section(
            'accordion_section', array(
                'label'         => esc_html__('Content', WT_DOMAIN),
            )
        );
        $this->add_control(
            'style', [
                'label'         => esc_html__('Style', WT_DOMAIN),
                'type'          => Controls_Manager::SELECT,
                'options'       => [
                    '1'		=> esc_html__('One', WT_DOMAIN),
                    '2'		=> esc_html__('Two', WT_DOMAIN),
                    '3'		=> esc_html__('Three', WT_DOMAIN),
					'4'		=> esc_html__('Four', WT_DOMAIN),
                ],
				'default'	=> '1',
            ]
        );
		$this->add_control(
			'title',[
				'label'         => esc_html__('Title', WT_DOMAIN),
				'type'          => Controls_Manager::TEXT,
			]
		);
		$this->add_control(
			'content',[
				'label'         => esc_html__('Content', WT_DOMAIN),
				'type'          => Controls_Manager::TEXT,
				'description' 	=> __('HTML tags allowed', WT_DOMAIN),
			]
		);
	}
	/**
	 * Render accordion widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		// make HTML attribute
        $this->add_render_attribute(
            'wt_accordion_settings',
            [
            	'id'                   => 'wt-accordion-' . $this->get_id(),
            ]
        );?>
		<div class="wt-accordion-main" <?php echo $this->get_render_attribute_string( 'wt_accordion_settings' ); ?> >
			<div class="wt-accordion toggle style<?php echo $settings['style']; ?>" >			
				<div class="single_toggle toogle_div">
					<a class="tog" href="#"><div class="toggle-title"><span class="icon"></span><?php echo $settings['title']; ?></div></a>
					<div class="tab_content <?php echo 'wt-accordion-' . $this->get_id(); ?>"><?php echo $settings['content']; ?></div>
				</div>
			</div>
		</div>
		<?php 
	}
}
Plugin::instance()->widgets_manager->register_widget_type(new Accordion_Elementor_Widget());