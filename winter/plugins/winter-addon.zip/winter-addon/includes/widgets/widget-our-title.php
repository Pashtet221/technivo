<?php
namespace Elementor;

/**
 * If this file is called directly, abort.
 */
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Class Our title
 */
class Our_Title_Elementor_Widget extends Widget_Base {

    // Function for get the slug of the element name.
        public function get_name() {
            return 'wt_our_title';
        }

    // Function for get the name of the element.
        public function get_title() {
            return esc_html__('WT Winter Title', WT_DOMAIN);
        }

    // Function for get the icon of the element.
        public function get_icon() {
            return 'eicon-t-letter';
        }

    // Function for include element into the category.
        public function get_categories() {
            return ['winter-addon-elements'];
        }

    // Function for include element keywords.
        public function get_keywords() {
            return ['wt_our_title', 'winter-addon-elements'];
        }

    // Funcyion for include css
        public function get_style_depends() {
            return ['wt_our_title'];
        }

    // Adding the controls fields for the Product-category-tab Element
    protected function register_controls() {
       
    $this->start_controls_section(
        'section_content',
        [
          'label' => 'Settings',
        ]
      );
  
      $this->add_control(
        'label_heading',
        [
          'label' => 'Title Heading',
          'type' => \Elementor\Controls_Manager::TEXT,
          'default' => 'Title'
        ]
      );
      
  
      $this->add_control(
        'content_heading',
        [
          'label' => 'Sub Title Heading',
          'type' => \Elementor\Controls_Manager::TEXT,
          'default' => 'Sub Title'
        ]
      );  
      $this->end_controls_section();
}

    
     /**
     * Render Our title Elements widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @access protected
     */
    protected function render() {
        $settings = $this->get_settings();
       

    ?>
    <div class="winter_both_title">
      <div class="winter_">
        <div class="winter_title">
          <h2><?php echo $settings['label_heading'] ?></h2>
        </div>
        <div class="winter_content">
          <h4><?php echo $settings['content_heading'] ?></h4>
        </div>
      </div>
    </div>
    <?php
	
}


}
Plugin::instance()->widgets_manager->register_widget_type(new Our_Title_Elementor_Widget());