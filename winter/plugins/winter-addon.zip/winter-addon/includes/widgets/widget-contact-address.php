<?php
namespace Elementor;

/**
 * If this file is called directly, abort.
 */
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Class WT Contact Address
 */
class  Contact_Address_Elementor_Widget extends Widget_Base {

// Function for get the slug of the element name.
    public function get_name() {
        return 'wt_contact_address';
    }

// Function for get the name of the element.
    public function get_title() {
        return esc_html__('WT Contact Address', WT_DOMAIN);
    }

// Function for get the icon of the element.
    public function get_icon() {
        return 'eicon-mail';
    }

// Function for include element into the category.
    public function get_categories() {
        return ['winter-addon-elements'];
    }

// Function for include element keywords.
    public function get_keywords() {
        return ['wt_contact_address', 'winter-addon-elements'];
    }

// Funcyion for include css
    public function get_style_depends() {
        return ['wt_contact_address'];
    }

    // Adding the controls fields for the WT Contact Address Element
    protected function register_controls() {
        $this->start_controls_section(
            'contact_address_section', array(
                'label'         => esc_html__('Content', WT_DOMAIN),
            )
        );
        $this->add_control(
			'title',[
				'label'         => esc_html__('Title', WT_DOMAIN),
				'type'          => Controls_Manager::TEXT,
			]
		);
        $this->add_control(
			'description',[
				'label'         => esc_html__('Description', WT_DOMAIN),
				'type'          => Controls_Manager::TEXT,
			]
		);
        $this->add_control(
			'address_label',[
				'label'         => esc_html__('Address Label', WT_DOMAIN),
				'type'          => Controls_Manager::TEXT,
                'default'       =>__('Address:',WT_DOMAIN),
			]
		);
        $this->add_control(
			'content',[
				'label'         => esc_html__('Address', WT_DOMAIN),
				'type'          => Controls_Manager::TEXT,
                'description' 	=> __('HTML tags allowed', WT_DOMAIN),
			]
		);
        $this->add_control(
			'phone_label',[
				'label'         => esc_html__('Phone Label', WT_DOMAIN),
				'type'          => Controls_Manager::TEXT,
                'default'       =>__('Phone numbers:',WT_DOMAIN),
			]
		);
        $this->add_control(
			'phone',[
				'label'         => esc_html__('Phone Number', WT_DOMAIN),
				'type'          => Controls_Manager::TEXT,
			]
		);
        $this->add_control(
			'email_label',[
				'label'         => esc_html__('Email Label', WT_DOMAIN),
				'type'          => Controls_Manager::TEXT,
                'default'       =>__('Email:',WT_DOMAIN),
			]
		);
        $this->add_control(
			'email',[
				'label'         => esc_html__('Email', WT_DOMAIN),
				'type'          => Controls_Manager::TEXT,
                'description' 	=> __('Give Email Address Here ex. support@Winter.com', WT_DOMAIN),
			]
		);
        $this->add_control(
			'email_link',[
				'label'         => esc_html__('Email Link', WT_DOMAIN),
				'type'          => Controls_Manager::TEXT,
                'description' 	=> __('(ex. mailto:support@Winter.com)', WT_DOMAIN),
			]
		);

        $this->add_control(
			'other_label',[
				'label'         => esc_html__('Other Label', WT_DOMAIN),
				'type'          => Controls_Manager::TEXT,
			]
		);
        $this->add_control(
			'other',[
				'label'         => esc_html__('Other', WT_DOMAIN),
				'type'          => Controls_Manager::TEXT,
                'description' 	=> __('ex,time of office', WT_DOMAIN),
			]
		);
    }

     /**
     * Render WT Contact Address Elements widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @access protected
     */
    protected function render() {
        $settings = $this->get_settings();?>

        <div class="address-container">
            <?php if(!empty($settings['title']))?>
                <h3 class="address-title simple-title"><span><?php echo($settings['title']);?></span></h3>
            <?php if(!empty($settings['description']))?>
                <div class="address-description description"><?php echo($settings['description']);?></div>
                <div class="address-text first">
                    <div class="address-text-inner">
                        <div class="icon"><i class="fa fa-map-marker"></i></div>
                        <div class="content"><div class="address-label"><?php echo($settings['address_label']);?></div><?php echo do_shortcode($settings['content']); ?></div> 
                    </div>
                </div>
            <?php if(!empty($settings['phone'])):?>
                <div class="address-text second">
                    <div class="address-text-inner">
                        <div class="icon"><i class="fa fa-phone"></i></div> 
                        <div class="content">
                            <div class="address-label"><?php echo($settings['phone_label']);?></div><?php echo($settings['phone']); ?>
                        </div>
                    </div>
                </div>
            <?php endif;
            if(!empty($settings['email'])):
                if(!empty($settings['email_link'])):?>
                    <div class="address-text third">
                        <div class="address-text-inner">
                            <div class="icon"><i class="fa fa-envelope "></i></div>
                            <div class="content">
                                <div class="address-label"><?php echo($settings['email_label']); ?></div>
                                <a href="<?php echo($settings['email_link']);?>"><?php echo($settings['email']);?></a>
                            </div>
                        </div>
                        <div class="other-des">
                                <?php echo($settings['other_label']); ?>
                                <p><?php echo($settings['other']); ?></p>
                            </div>
                    </div>
                <?php else:?>
                    <div class="address-text">
                        <div class="address-text-inner">
                            <div class="icon"><i class="fa fa-envelope "></i></div>  
                            <div class="content"><div class="address-label"><?php echo($settings['email_label']); ?></div><?php echo($settings['email']);?></div>
                        </div>
                    </div>
                <?php endif;
            endif;	?>
		</div><?php
    }
}
Plugin::instance()->widgets_manager->register_widget_type(new Contact_Address_Elementor_Widget());