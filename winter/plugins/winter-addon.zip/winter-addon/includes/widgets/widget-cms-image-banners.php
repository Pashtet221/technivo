<?php
namespace Elementor;

/**
 * If this file is called directly, abort.
 */
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Class  WT CMS Image Banners
 */
class  CMS_Image_Banners_Elementor_Widget extends Widget_Base {

// Function for get the slug of the element name.
    public function get_name() {
        return 'wt_cms_image_banners';
    }

// Function for get the name of the element.
    public function get_title() {
        return esc_html__('WT CMS Image Banners', WT_DOMAIN);
    }

// Function for get the icon of the element.
    public function get_icon() {
        return 'eicon-banner';
    }

// Function for include element into the category.
    public function get_categories() {
        return ['winter-addon-elements'];
    }

// Function for include element keywords.
    public function get_keywords() {
        return ['wt_cms_image_banners', 'winter-addon-elements'];
    }

// Funcyion for include css
    public function get_style_depends() {
        return ['wt_cms_image_banners'];
    }

// Adding the controls fields for the WT CMS Image Banners Element
    protected function register_controls() {
        $this->start_controls_section(
            'cms_banner_section', array(
                'label'         => esc_html__('Content', WT_DOMAIN),
            )
        );
        $this->add_control(
            'classname',[
                'label'         => esc_html__('Classname', WT_DOMAIN),
                'type'          => Controls_Manager::TEXT,
                'description'   => __('Give classname for this block', WT_DOMAIN),
            ]
        );
        $this->add_control(
            'image',[
                'label'         => esc_html__('Choose Image', WT_DOMAIN),
                'type'          => Controls_Manager::MEDIA,
                'dynamic'       => [
                    'active' => true,
                ],
                'default'       => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
            ]
        );
        $this->add_control(
            'style', [
                'label'         => esc_html__('Style Type', WT_DOMAIN),
                'type'          => Controls_Manager::SELECT,
                'options'       => [
                    '1'     => __('One', WT_DOMAIN),
                    '2'     => __('Two', WT_DOMAIN),
                ],
                'default'       => '1',
                'description'   => __('Select type of Hover effect.', WT_DOMAIN),
            ]
        );
        $this->add_control(
            'link_text',[
                'label'         => esc_html__('Link Text', WT_DOMAIN),
                'type'          => Controls_Manager::TEXT,
                'description'   => __('URL linkable text  ex.Shop Now', WT_DOMAIN),
            ]
        );
        $this->add_control(
            'link_url',[
                'label'         => esc_html__('Link URL', WT_DOMAIN),
                'type'          => Controls_Manager::TEXT,
                'description'   => __('ex. https://www.google.co.in/', WT_DOMAIN),
            ]
        );
        $this->add_control(
            'target', [
                'label'         => esc_html__('Button | Target', WT_DOMAIN),
                'type'          => Controls_Manager::SELECT,
                'options'       => [
                    ''          => __('Default | _self',WT_DOMAIN),
                    '_blank'    => __('New Tab or Window | _blank',WT_DOMAIN),
                ],
                'description'   => __('Define where to open the linked document', WT_DOMAIN),
            ]
        );
        $this->add_control(
            'text1',[
                'label'         => esc_html__('Text1', WT_DOMAIN),
                'type'          => Controls_Manager::TEXT,
                'description'   => __('Text1  ex. Table Lights', WT_DOMAIN),
            ]
        );
        $this->add_control(
            'text2',[
                'label'         => esc_html__('Text2', WT_DOMAIN),
                'type'          => Controls_Manager::TEXT,
                'description'   => __('Text2  ex. The World Catelog Ideas', WT_DOMAIN),
            ]
        );
        $this->add_control(
            'text3',[
                'label'         => esc_html__('Text3', WT_DOMAIN),
                'type'          => Controls_Manager::TEXT,
                'description'   => __('Text3  ex. Table Lights', WT_DOMAIN),
            ]
        );

    }
    
    /**
     * Render WT CMS Image Banners Elements widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @access protected
     */
    protected function render() {
        $settings = $this->get_settings();
        $hover_class = '';  
        $cmstext1 = "" ;
        $cmstext2 = "";
        $cmstext3 = "";
        $link_text = "";
        $cmstarget = "" ;

        if(!empty($settings['text1'])) :    
            $cmstext1 = '<span class="text1 static-text">'.$settings['text1'].'</span>';
        endif;
        if(!empty($settings['text2'])) :
            $cmstext2 = '<span class="text2 static-text">'.$settings['text2'].'</span>';    
        endif;
        if(!empty($settings['text3'])) :
            $cmstext3 = '<span class="text3 static-text">'.$settings['text3'].'</span>';    
        endif;
        if(!empty($settings['link_text'])) :
            $link_text = '<span class="text-button"><a href="'.$settings['link_url'].'" target="_self" class="link-text">'.$settings['link_text'].'<svg width="16px" height="14px"><use xlink:href="#arrowright"></use></svg></a></span>';            
        endif;
        if(!empty($settings['image'])) :
            $image = '<img src="'.$settings['image']['url'].'" alt=""/>';           
         endif;
        if(!empty($settings['target'])) :
            $cmstarget = 'target="'.$settings['target'].'"';
        endif;?>
        <div class="cms-banner-item <?php echo $settings['classname']; ?><?php echo $hover_class; ?> style-<?php echo $settings['style']; ?>">
            <div class="cms-banner-inner">
                <div class="cms-banner-img">
                    <a class="image-link" href="<?php echo $settings['link_url']; ?><?php echo $cmstarget; ?>" title="<?php the_title();?>"><?php echo $image; ?></a>
                    <span class="static-wrapper">
                        <span class="static-inner"><?php echo $cmstext1; echo $cmstext2; echo $cmstext3; echo $link_text; ?></span>
                    </span>
                </div>
            </div>
        </div><?php
    }
}
Plugin::instance()->widgets_manager->register_widget_type(new CMS_Image_Banners_Elementor_Widget());