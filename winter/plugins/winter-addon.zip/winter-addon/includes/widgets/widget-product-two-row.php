<?php
namespace Elementor;

/**
 * If this file is called directly, abort.
 */
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Class Product
 */
class Vertical_Product_Elementor_Widget extends Widget_Base {

    // Function for get the slug of the element name.
        public function get_name() {
            return 'wt_vertical_product';
        }

    // Function for get the name of the element.
        public function get_title() {
            return esc_html__('WT Product Two Row', WT_DOMAIN);
        }

    // Function for get the icon of the element.
        public function get_icon() {
            return 'eicon-product-images';
        }

    // Function for include element into the category.
        public function get_categories() {
            return ['winter-addon-elements'];
        }

    // Function for include element keywords.
        public function get_keywords() {
            return ['vertical-product', 'winter-addon-elements'];
        }

    // Funcyion for include css
        public function get_style_depends() {
            return ['vertical-product'];
        }
        public function get_script_depends() {
            return ['vertical-product'];
        }

        // Adding the controls fields for the Product-category-tab Element
        protected function register_controls() {

            $this->start_controls_section(
                'product_section', array(
                    'label'         => esc_html__('Content', WT_DOMAIN),
                )
            );
            $this->add_control(
                'type', [
                    'label'         => esc_html__('Type', WT_DOMAIN),
                    'type'          => Controls_Manager::SELECT,
                    'options'       => [
                        'grid'		=> esc_html__('Grid', WT_DOMAIN),	
                        'slider'	=> esc_html__('Slider', WT_DOMAIN),
                    ],
                    'default'       => 'grid',
                ]
            );
            $this->add_control(
                'classname',[
                    'label'         => esc_html__('Classname', WT_DOMAIN),
                    'type'          => Controls_Manager::TEXT,
                    'description' 	=> __('classname', WT_DOMAIN),
                ]
            );
            $this->add_control(
                'content',[
                    'label'         => esc_html__('Heading', WT_DOMAIN),
                    'type'          => Controls_Manager::TEXT,
                ]
            );
            $this->add_control(
                'items_per_column', [
                    'label'         => esc_html__('Items Per Column', WT_DOMAIN),
                    'type'          => Controls_Manager::SELECT,
                    'options'       => [
                        '1'		=> esc_html__('1', WT_DOMAIN),
                        '2'		=> esc_html__('2', WT_DOMAIN),
                        '3'		=> esc_html__('3', WT_DOMAIN),
                        '4'		=> esc_html__('4', WT_DOMAIN),
                        '5'		=> esc_html__('5', WT_DOMAIN),
                        '6'		=> esc_html__('6', WT_DOMAIN),
                    ],  
                    'frontend_available' => true,
                    'default'       => 3,
                    
                ]
            );
            $this->add_control(
                'items_per_page', [
                    'type'    => Controls_Manager::NUMBER,
                    'label'   => esc_html__( 'Items Per Page', WT_DOMAIN ),
                    'default' => 3,
                    'description' 	=> __('Enter number of items to display per column.', WT_DOMAIN),			
                ]
            );
            $this->add_control(
                'orderby', [
                    'label' => __('Order By', WT_DOMAIN),
                    'type' => Controls_Manager::SELECT,
                    'default' => 'id',
                    'options' => [
                        'id' => __('ID', WT_DOMAIN),
                        'date' => __('Date', WT_DOMAIN),
                        'title' => __('Title', WT_DOMAIN),
                        'price' => __('Price', WT_DOMAIN),
                        'rating' => __('Rating', WT_DOMAIN),
                        'rand' => __('Random', WT_DOMAIN),
                    ],		
            ]
        );
        $this->add_control(
                'order', [
                    'label' => __('Order', WT_DOMAIN),
                    'type' => Controls_Manager::SELECT,
                    'default' => 'desc',
                    'options' => [
                        'asc' => __('ASC', WT_DOMAIN),
                        'desc' => __('DESC', WT_DOMAIN),
                    ],
                    
                ]
        );
        $this->add_control(
            'categories', [
                 'label' => esc_html__('Categories',WT_DOMAIN),
                 'type' => Controls_Manager::SELECT2,
                 'label_block' => true,
                 'multiple' => true,
                 'description' => esc_html__('Select the categories you want to show',WT_DOMAIN),
                 'options' => woo_product_categories(),
                 'separator' => 'before',
            ]   
       );
    }
    /**
     * Render Product Elements widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @access protected
     */
    protected function render() {
        $settings = $this->get_settings();
        $this->add_render_attribute( 'countdown-wrapper', 'class', 'ansh-countdown-wrapper' );
        global $logotype;
        $items_per_column = $settings['items_per_column'];
        $items_per_page = $settings['items_per_page'];
        $category_ids_array = $settings['categories'];
        $type = $settings['type'];
        $orderby = $settings['orderby'];
        $order = $settings['order'];
        $logotype = $type;

        // make HTML attribute
        $this->add_render_attribute(
            'wt_product_two_row_setting',
            [
                'id'                   => 'wt-product-two-row-' . $this->get_id(),
                'data-page-per-view'   => $settings[ 'items_per_column' ],
                'data-slider'          => $settings['type'],
                'data-view-product'    =>  $items_per_page,
            ]
        );
        //get categoires sluge array
        $term_category_slug = array();
        foreach($term_category_slug as $key){
            $category_ids = get_term( $key, 'product_cat' );
            
            $term_category_slug[] = $category_ids->slug;
        }
        $category_slug  = implode( ', ' , $term_category_slug);
        ?>   
            <div class="product-two-row " <?php echo $this->get_render_attribute_string( 'wt_product_two_row_setting' ); ?>>
                <div id="woo-products-var" class="woo-products-var woo-content products_block shop <?php echo $settings['classname']; ?>" > 
                        <?php  if($settings['type'] == "slider") { ?> 
                        <div id="<?php echo $settings['items_per_column']; ?>_woo_slick" class="woo-slick two_row cols-<?php echo $settings['items_per_column'];?>" >
                            <?php } else { ?>
                        <div id="woo_grid" class=" woo-grid cols-<?php echo $settings['items_per_column'];?>">
                            <?php } ?> 
                            <div class="woo-heading woo-cs-product-two-row product-grid-container"> <?php echo do_shortcode($settings['content']);?><?php
                               if($settings['type'] == "grid") { 
                                    echo do_shortcode('[recent_products per_page="" Columns="'.$items_per_column.'" orderby="'.$orderby.'" order="'.$order.'" category="'.$category_slug.'"]');
                               }else{
                                   echo do_shortcode('[recent_products per_page="'.$items_per_page.'" Columns="'.$items_per_column.'" orderby="'.$orderby.'" order="'.$order.'" category="'.$category_slug.'"]'); 
                               } ?>
                            </div>
                        </div> 
                        <?php
                    if($settings['type'] == "grid") { ?>
                        <div class="wntr-message"><i class="fa fa-frown-o"></i><?php echo $no_more; ?></div>
                        <div class="loadgridlist-wrapper "><button class="woocount loadgridlist" ><?php echo esc_html__('View More Products', 'technivo');?></button></div>
                    <?php } ?>
                </div>
            </div>
        <?php
    }
}
Plugin::instance()->widgets_manager->register_widget_type(new Vertical_Product_Elementor_Widget());