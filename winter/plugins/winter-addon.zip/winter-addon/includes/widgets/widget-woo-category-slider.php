<?php
namespace Elementor;
/**
 * If this file is called directly, abort.
 */
if (!defined('ABSPATH')) {
    exit;
}
/**
 * Class WT Woo Category Slider
 */
class  Woo_Category_Slider_Elementor_Widget extends Widget_Base {
// Function for get the slug of the element name.
    public function get_name() {
        return 'wt_woo_category_slider';
    }
// Function for get the name of the element.
    public function get_title() {
        return esc_html__('WT Woo Category Slider', WT_DOMAIN);
    }
// Function for get the icon of the element.
    public function get_icon() {
        return 'eicon-product-categories';
    }
// Function for include element into the category.
    public function get_categories() {
        return ['winter-addon-elements'];
    }
// Function for include element keywords.
    public function get_keywords() {
        return ['wt_woo_category_slider', 'winter-addon-elements'];
    }
// Funcyion for include css
    public function get_style_depends() {
        return ['wt_woo_category_slider'];
    }
    
    // Adding the controls fields for the WT Woo Category Slider
    protected function register_controls() {
        $this->start_controls_section(
            'woo_category_section', array(
                'label'         => esc_html__('Content', WT_DOMAIN),
            )
        );
        $this->add_control(
            'items_per_column', [
                'label'         => esc_html__('Items Per Column', WT_DOMAIN),
                'type'          => Controls_Manager::SELECT,
                'options'       => [
                    '1'		=> esc_html__('1', WT_DOMAIN),
                    '2'		=> esc_html__('2', WT_DOMAIN),
                    '3'		=> esc_html__('3', WT_DOMAIN),
                    '4'		=> esc_html__('4', WT_DOMAIN),
                    '5'		=> esc_html__('5', WT_DOMAIN),
                    '6'		=> esc_html__('6', WT_DOMAIN),
                    '7'     => esc_html__('7', WT_DOMAIN),
                ],
                'default'       => '3',
                'description' 	=> __('Enter number of items to display per column.', WT_DOMAIN),
            ]
        );
        $this->add_control(
            'display_category', [
                'label'         => esc_html__('Category Display', WT_DOMAIN),
                'type'          => Controls_Manager::SELECT,
                'options'       => [
                    '0'		=> esc_html__('Parent', WT_DOMAIN),
                    ''		=> esc_html__('ParentCategory + SubCategory', WT_DOMAIN),
                ],
                'description' 	=> __('Default category display.', WT_DOMAIN),
            ]
        );
        $this->add_control(
            'hide_empty', [
                'label'         => esc_html__('Hide Empty Category', WT_DOMAIN),
                'type'          => Controls_Manager::SELECT,
                'options'       => [
                    '1'		=> esc_html__('Yes', WT_DOMAIN),
                    '0'		=> esc_html__('No', WT_DOMAIN),
                ],
                'description' 	=> __('select option for hide/display empty category', WT_DOMAIN),
            ]
        );
        $this->end_controls_section();
        $this->start_controls_section(
            'style_sec', [
                'tab'           => Controls_Manager::TAB_STYLE,
                'label' => __( 'Image', WT_DOMAIN ),
            ]
        );
        $this->add_responsive_control(
			'width',[
				'label' => __('Category Image Width', WT_DOMAIN ),
				'type' => Controls_Manager::SLIDER,
				'default' => [
					'unit' => '%',
				],
				'tablet_default' => [
					'unit' => '%',
				],
				'mobile_default' => [
					'unit' => '%',
				],
				'size_units' => [ '%', 'px', 'vw' ],
				'range' => [
					'%' => [
						'min' => 1,
						'max' => 100,
					],
					'px' => [
						'min' => 1,
						'max' => 1000,
					],
					'vw' => [
						'min' => 1,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .cat-image' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
        
		$this->add_responsive_control(
			'height',
			[
				'label' => __( 'Category Image Height', WT_DOMAIN ),
				'type' => Controls_Manager::SLIDER,
				'default' => [
					'unit' => 'px',
				],
				'tablet_default' => [
					'unit' => 'px',
				],
				'mobile_default' => [
					'unit' => 'px',
				],
				'size_units' => [ 'px', 'vh' ],
				'range' => [
					'px' => [
						'min' => 1,
						'max' => 500,
					],
					'vh' => [
						'min' => 1,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .cat-image' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);
        $this->add_control(
                'img_border_radius', [
            'label' => esc_html__('Border Radius', WT_DOMAIN),
            'type' => Controls_Manager::DIMENSIONS,
            'size_units' => ['px', '%'],
            'selectors' => [
                '{{WRAPPER}} .cat-image' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
         );
        $this->add_group_control(
                Group_Control_Css_Filter::get_type(), [
            'name' => 'thumbnail_filters',
            'selector' => '{{WRAPPER}} .cat-image',
                ]
        );
        $this->end_controls_section();
    
    }
     /**
     * Render WT Woo Category Slider Elements widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @access protected
     */
    protected function render() {
        $settings = $this->get_settings();
        $category_ids_array = explode(",",'product_cat');	
        $name='';
        $readmore=''; 
        // make HTML attribute
        $this->add_render_attribute(
            'wt_woo_category_slider_setting',
            [
                'id'                   => 'wt-woo-category-slider-' . $this->get_id(),
                'data-page-per-view'   => $settings[ 'items_per_column' ],
            ]
        );
        if ( in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) :?>
            <div class="woo_categories_slider" <?php echo $this->get_render_attribute_string( 'wt_woo_category_slider_setting' ); ?> >
                <div id="<?php echo  $settings['items_per_column']; ?>_category_carousel" class="category-carousel">
                    <?php $args = array(
                        'parent'        => $settings['display_category'],
                        'hide_empty'    =>  $settings['hide_empty'],
                        'taxonomy'      => 'product_cat',
                    );
                    $categories = get_categories( $args );
                    foreach($categories as $cat){	
                        $category_ids = get_term( $cat, 'product_cat' );
                        $thumbnail_id = get_term_meta( $cat->term_id, 'thumbnail_id', true );
                        $width = "";
                        $height = "";
                        if( empty ($thumbnail_id)):
                            $image = get_template_directory_uri()."/images/webi/category-placeholder.jpg";		
                        else:
                            $image = wp_get_attachment_url( $thumbnail_id );				
                        endif;
                        $src = wntr_mr_image_resize($image, $width, $height, true, 't', false);?>
                        <a class="catlink" href="<?php echo get_category_link( $category_ids );?>" title="<?php echo $cat->name;?>" >
                        <div class="cat-outer-block">
                           <div class="cat-img-block">
                                <img class="cat-image" src="<?php echo $src; ?>" title="<?php echo $cat->name; ?>" alt="<?php echo $cat->name; ?>"/>
                            </div>
                            <div class="cat_description"> 
                                <div class="cattitle">
                                    <h3 class="cat_name"><?php echo $cat->name;?></h3>
                                    <div class="cat-item"><?php echo $cat->count;?> items in Stock</div>
                                    <div class="cat_inner_description"><?php echo $cat->description;?></div>
                              </div>
                        </div>
                        </div>
                    </a>
                    <?php } ?>
                </div>
            </div><?php
        endif; 
    }
}
Plugin::instance()->widgets_manager->register_widget_type(new Woo_Category_Slider_Elementor_Widget());
