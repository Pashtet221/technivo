<?php 
/**
 * Return product category array.
 */
if (!function_exists('woo_product_categories')) {

    function woo_product_categories() {

         $orderby = 'name';
         $order = 'asc';
         $hide_empty = true ;
         $cat_args = array(
             'orderby'    => $orderby,
             'order'      => $order,
             'hide_empty' => $hide_empty,
         );
          
         $product_categories = get_terms( 'product_cat', $cat_args );
          
         $product_cat = array();
         if( !empty($product_categories) && !is_wp_error($product_categories) ){
             foreach ($product_categories as $category) {
                $product_cat[$category->term_id] = $category->name;

             }
                 
       }
       return $product_cat;

    }
}