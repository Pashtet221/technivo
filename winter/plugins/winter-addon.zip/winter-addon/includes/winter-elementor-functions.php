<?php
/**
 * Enqueue scripts and styles.
 *
 */
function winter_elementor_scripts() {
	
	wp_enqueue_style('wt-owlcarousel', WT_ADDON_DIR . 'assets/css/owlcarousel/owl.carousel.min.css');
	wp_enqueue_style('wt-elementor-style', WT_ADDON_DIR . 'assets/css/winter-style.css');
	
	wp_enqueue_script( 'wt-owl-carousel', WT_ADDON_DIR . 'assets/js/owlcarousel/owl.carousel.js', array('jquery'), '', true );
	wp_enqueue_script( 'wt-elementor-js', WT_ADDON_DIR . 'assets/js/winter-elementor.js', array('jquery'), '', true );	
}
add_action( 'wp_enqueue_scripts', 'winter_elementor_scripts', 20 );

/**
 * Return post category array. .
 */
function winter_blog_categories() {

	$terms = get_terms( array( 
							'taxonomy' => 'category',
							'hide_empty' => true,
						)
					);
    
    $options = array();
    if ( ! empty( $terms ) && ! is_wp_error( $terms ) ) {
		foreach ( $terms as $term ) {
			$options[ $term->term_id ] = $term->name;
		}
    }
    
    return $options;
}

/**
 * Return product category array.
 */
function winter_product_categories() {

	$orderby = 'name';
	$order = 'asc';
	$hide_empty = true ;
	$cat_args = array(
		 'orderby'    => $orderby,
		 'order'      => $order,
		 'hide_empty' => $hide_empty,
	 );
	  
	$product_categories = get_terms( 'product_cat', $cat_args );
	  
	$product_cat = array();
	if( !empty($product_categories) && !is_wp_error($product_categories) ){
		 foreach ($product_categories as $category) {
			$product_cat[$category->term_id] = $category->name;

		 }
			 
   }
   return $product_cat;

}

// On Editor - Register WooCommerce frontend hooks before the Editor init.
// Priority = 5, in order to allow plugins remove/add their wc hooks on init.
if (!empty($_REQUEST['action']) && 'elementor' === $_REQUEST['action']) {
	add_action('init', 'wt_register_wc_hooks', 5);
}

/**
 *  call wt_register_wc_hooks
*/
if(!function_exists('wt_register_wc_hooks')){

	function wt_register_wc_hooks(){
		
		if (class_exists('WooCommerce')) {

            wc()->frontend_includes();

        }
	}
}