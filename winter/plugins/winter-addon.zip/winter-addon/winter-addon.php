<?php
/*
Plugin Name: Webibazaar Addon
Description: Webibazaar Custom Shortcodes for Webibazaar wordpress themes.
Version: 1.0
Author: Webibazaar
*/

if (!defined('ABSPATH')) {
  exit; // Exit if accessed directly
}

/**
* Define Plugin URL and Directory Path
*/
define('WT_ADDON_DIR', plugins_url('/', __FILE__));  // Define Plugin URL
define('WT_PATH', plugin_dir_path(__FILE__));        // Define Plugin Directory Path
define('WT_DOMAIN', 'winter-addon-for-elementor');   // Define Text Domain

/**
 * Load plugin textdomain.
 */
function winter_addon_plugin_textdomain() {
	load_plugin_textdomain( 'winter-elementor-elements', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );	
	
	if (!did_action('elementor/loaded')) {
	   add_action('admin_notices', 'winter_addon_widget_fail_load');
	  return;
	}
}

add_action( 'plugins_loaded', 'winter_addon_plugin_textdomain' );

/**
 * Winter Elementor Elements Register Categories.
 *
 */
function winter_elementor_elments_categories_registered( $elements_manager  ){

   $elements_manager->add_category(
        'winter-addon-elements',
        [
            'title'  => 'Winter Builder',
            'icon' => 'fa fa-plug'
        ]
    );
}

add_action( 'elementor/elements/categories_registered', 'winter_elementor_elments_categories_registered' );

/**
 * This notice will appear if Elementor is not installed or activated or both
 */
function winter_addon_widget_fail_load() {
	$screen = get_current_screen();
	if (isset($screen->parent_file) && 'plugins.php' === $screen->parent_file && 'update' === $screen->id) {
		return;
	}

	$plugin = 'elementor/elementor.php';
	$installed_plugins = get_plugins();

	if (isset($installed_plugins[$plugin])) {
		if (!current_user_can('activate_plugins')) {
			  return;
		}
		$activation_url = wp_nonce_url('plugins.php?action=activate&amp;plugin=' . $plugin . '&amp;plugin_status=all&amp;paged=1&amp;s', 'activate-plugin_' . $plugin);
		$message = '<p><strong>' . __('Webibazaar Addon for Elementor plugin is not working because you need to activate the Elementor plugin.', WT_DOMAIN).'</strong></p>';
		$message .= '<p>' . sprintf('<a href="%s" class="button-primary">%s</a>', $activation_url, __('Activate Elementor Now', WT_DOMAIN)) . '</p>';
	} else {
		if (!current_user_can('install_plugins')) {
			return;
		}
		$install_url = wp_nonce_url(self_admin_url('update.php?action=install-plugin&plugin=elementor'), 'install-plugin_elementor');
		$message = '<p><strong>' . __('Webibazaar Addon for Elementor plugin is not working because you need to install the Elementor plugin', WT_DOMAIN) . '</strong></p>';
		$message .= '<p>' . sprintf('<a href="%s" class="button-primary">%s</a>', $install_url, __('Install Elementor Now', WT_DOMAIN)) . '</p>';
	}
	echo '<div class="error"><p>' . $message . '</p></div>';
}

/**
 * Require files.
 *
 * Winter Elementor Elements Register Elements ( Widgets).
 *
 */
function winter_elementor_elments_widgets_registered(){

	/* Elementor widget file */
	require_once WT_PATH . 'includes/widgets/widget-our-team.php';
	require_once WT_PATH . 'includes/widgets/widget-product.php';
	require_once WT_PATH . 'includes/widgets/widget-cms-image-banners.php';
	require_once WT_PATH . 'includes/widgets/widget-contact-address.php';
	require_once WT_PATH . 'includes/widgets/widget-link.php';
	require_once WT_PATH . 'includes/widgets/widget-service.php';
	require_once WT_PATH . 'includes/widgets/widget-pricing-table.php';
	require_once WT_PATH . 'includes/widgets/widget-woo-category-slider.php';
	require_once WT_PATH . 'includes/widgets/widget-blog.php';
	require_once WT_PATH . 'includes/widgets/widget-custom-testimonial.php';
	require_once WT_PATH . 'includes/widgets/widget-product-two-row.php';
	require_once WT_PATH . 'includes/widgets/widget-our-title.php';
	require_once WT_PATH . 'includes/widgets/function-cat.php';
	require_once WT_PATH . 'includes/widgets/widget-product-category.php';
	require_once WT_PATH . 'includes/widgets/widget-best-selling-product.php';
	require_once WT_PATH . 'includes/widgets/widget-top-rated-product.php';
	require_once WT_PATH . 'includes/widgets/widget-home-page-service.php';
	require_once WT_PATH . 'includes/widgets/widget-accordion.php';
	require_once WT_PATH . 'includes/widgets/widget-hot-product.php';
	require_once WT_PATH . 'includes/widgets/widget-product-with-tab.php';
		
}

add_action( 'elementor/widgets/widgets_registered', 'winter_elementor_elments_widgets_registered' );

require_once WT_PATH . 'includes/winter-custom-post.php';
require_once WT_PATH . 'includes/winter-elementor-functions.php';